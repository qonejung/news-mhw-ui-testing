import React from 'react';
import XPrototype from './prototype/XPrototype';
import './prototype/x-prototype.css';

export default function App() {
  return <XPrototype />;
}
