# CSS Media – X-inspired mobile news feed prototype v1

A mobile-first web-only, X-style UI prototype based on the Facebook v3 project.

## Features
- Exactly three immigration news stories per selected condition (Neutral, POLAR_POS, POLAR_NEG).
- CSS Media fictional publisher @cssmedia; placeholder post text and grey image slots.
- X-inspired timeline, link cards, reply, repost, like, bookmark and share actions; no public counters or replies initially.
- An in-app-browser styled reader with the original article body and true/false question.
- Two tappable yellow-highlighted sentences; tap again to remove.
- Completion gate: exactly two highlights, quiz response and 10 seconds of visible article time (all configurable).
- Article session logs include scroll trajectory, first visible paragraphs, visible and elapsed time, quiz submission, highlights, completion status; export JSON via menu. Logs are stored in the browser, not a server.

## Running
- Open `css-media-x-preview.html` directly in a desktop or mobile browser to use the standalone version. It contains all article data and runtime dependencies.
- To use the editable React/Vite source: run `npm install`, then `npm run dev` and open the local URL. Build with `npm run build`.
- Update the standalone HTML after changing React source with `node tools/build-standalone-offline.cjs` (offline builder requires the TypeScript runtime used in this environment).

## Scope
This is a UI exploration only. Step 1, post-exposure psychological measures, Step 3 and server storage are not included. Article previews are temporary excerpts from the source articles and need independent validation for experimental use. The X-inspired app chrome is a design reference, not an integration with X.
