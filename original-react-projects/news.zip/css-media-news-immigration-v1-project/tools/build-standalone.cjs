// Offline JSX transpiler and tiny CommonJS wrapper for the standalone HTML preview.
// Run: node tools/build-standalone.cjs (requires locally installed Babel parser etc.)
const fs=require('fs'); const path=require('path');
const parser=require('@babel/parser'); const traverse=require('@babel/traverse').default;
const generate=require('@babel/generator').default; const t=require('@babel/types');
const root=path.join(__dirname,'..');
const source=fs.readFileSync(path.join(root,'src/prototype/NewsPrototype.jsx'),'utf8');
const ast=parser.parse(source,{sourceType:'module',plugins:['jsx']});
function name(n){if(n.type==='JSXIdentifier')return t.identifier(n.name);if(n.type==='JSXMemberExpression')return t.memberExpression(name(n.object),name(n.property));throw new Error('Unexpected jsx tag');}
function attr(n){if(n.type==='JSXSpreadAttribute')return t.spreadElement(n.argument);let key=t.isValidIdentifier(n.name.name)?t.identifier(n.name.name):t.stringLiteral(n.name.name);let val=n.value? n.value.type==='StringLiteral'?n.value: n.value.type==='JSXExpressionContainer'?n.value.expression: n.value : t.booleanLiteral(true);return t.objectProperty(key,val);}
function normaliseText(value){const parts=value.split(/\r\n|\n|\r/);let last=parts.length-1;let out='';for(let i=0;i<=last;i++){let line=parts[i].replace(/\t/g,' ');if(i!==0)line=line.replace(/^ +/,'');if(i!==last)line=line.replace(/ +$/,'');if(line){out+=line;if(i!==last)out+=' ';}}return out;}
function child(n){if(n.type==='JSXText'){const s=normaliseText(n.value);return s?t.stringLiteral(s):null;}if(n.type==='JSXExpressionContainer'){return n.expression.type==='JSXEmptyExpression'?null:n.expression;}return n;}
traverse(ast,{
  JSXElement:{exit(p){const node=p.node;const tag=node.openingElement.name;const tagName=tag.type==='JSXIdentifier' && /^[a-z]/.test(tag.name)? t.stringLiteral(tag.name):name(tag);const attrs=node.openingElement.attributes.map(attr);const props=attrs.length?t.objectExpression(attrs):t.nullLiteral();p.replaceWith(t.callExpression(t.memberExpression(t.identifier('React'),t.identifier('createElement')),[tagName,props,...node.children.map(child).filter(Boolean)]));}},
  JSXFragment:{exit(p){p.replaceWith(t.callExpression(t.memberExpression(t.identifier('React'),t.identifier('createElement')),[t.memberExpression(t.identifier('React'),t.identifier('Fragment')),t.nullLiteral(),...p.node.children.map(child).filter(Boolean)]));}},
  ImportDeclaration(p){p.remove();},
  ExportDefaultDeclaration(p){p.replaceWith(p.node.declaration);},
});
const jsxCode=generate(ast,{comments:false,compact:false}).code;
const libs={
  react:fs.readFileSync(path.join(root,'node_modules/react/cjs/react.production.js'),'utf8'),
  'react-dom':fs.readFileSync(path.join(root,'node_modules/react-dom/cjs/react-dom.production.js'),'utf8'),
  scheduler:fs.readFileSync(path.join(root,'node_modules/scheduler/cjs/scheduler.production.js'),'utf8'),
  'react-dom/client':fs.readFileSync(path.join(root,'node_modules/react-dom/cjs/react-dom-client.production.js'),'utf8'),
};
const bundle=`(function(){
const __moduleFactories={${Object.entries(libs).map(([k,v])=>`${JSON.stringify(k)}:function(module,exports,require){\n${v}\n}`).join(',\n')}};
const __moduleCache={};function require(n){if(__moduleCache[n])return __moduleCache[n].exports;if(!__moduleFactories[n])throw Error('Module not bundled: '+n);const m={exports:{}};__moduleCache[n]=m;__moduleFactories[n](m,m.exports,require);return m.exports;}
const React=require('react'); const ReactDOMClient=require('react-dom/client'); const {useEffect,useMemo,useRef,useState}=React;
const sourceArticles=${fs.readFileSync(path.join(root,'src/prototype/immigrationArticles.json'),'utf8')};
${jsxCode}
ReactDOMClient.createRoot(document.getElementById('root')).render(React.createElement(NewsPrototype));
})();`;
const css=fs.readFileSync(path.join(root,'src/prototype/news-prototype.css'),'utf8');
const html=`<!doctype html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover"/><meta name="theme-color" content="#ffffff"/><title>CSS Media | Mobile News Website UI Prototype</title><style>${css}</style></head><body><div id="root"></div><script>${bundle.replace(/<\/script/gi,'<\\/script')}</script></body></html>`;
const target=path.join(root,'css-media-news-web-preview.html');fs.writeFileSync(target,html);console.log('Wrote',target,'bytes',Buffer.byteLength(html));
