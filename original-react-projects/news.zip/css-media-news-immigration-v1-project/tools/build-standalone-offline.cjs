// Rebuild the standalone mobile web HTML without downloading packages.
// TypeScript is pre-installed in this execution environment; this builder reuses
// the React runtime embedded in the previous standalone HTML.
const fs=require('fs'); const path=require('path');
const ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js');
const root=path.join(__dirname,'..');
const previous=fs.readFileSync(path.join(root,'standalone-v2-runtime-source.html'),'utf8');
const script=previous.slice(previous.indexOf('<script>')+8, previous.indexOf('</script>'));
const base=script.slice(0,script.indexOf('const sourceArticles='));
if(!base.includes('const React=require')) throw new Error('Could not locate embedded React runtime');
const raw=fs.readFileSync(path.join(root,'src/prototype/NewsPrototype.jsx'),'utf8').replace(/^import .*?;\s*$/gm,'').replace('export default function NewsPrototype','function NewsPrototype');
const compiled=ts.transpileModule(raw,{compilerOptions:{jsx:ts.JsxEmit.React,module:ts.ModuleKind.None,target:ts.ScriptTarget.ES2020}}).outputText;
const sourceArticles=fs.readFileSync(path.join(root,'src/prototype/immigrationArticles.json'),'utf8');
const allJS=base+'\nconst sourceArticles='+sourceArticles+';\n'+compiled+'\nReactDOMClient.createRoot(document.getElementById("root")).render(React.createElement(NewsPrototype));\n})();';
const css=fs.readFileSync(path.join(root,'src/prototype/news-prototype.css'),'utf8');
const html='<!doctype html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1.0,viewport-fit=cover"/><meta name="theme-color" content="#ffffff"/><title>CSS Media · Mobile News Website</title><style>'+css+'</style></head><body><div id="root"></div><script>'+allJS.replace(/<\/script/gi,'<\\/script')+'</script></body></html>';
const target=path.join(root,'css-media-news-web-preview.html');
fs.writeFileSync(target,html);console.log('Wrote',target,Buffer.byteLength(html));
