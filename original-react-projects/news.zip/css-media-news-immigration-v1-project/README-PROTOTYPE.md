# CSS Media | Mobile news website UI prototype (v1)

Mobile-first, web-only CSS Media news site. Demonstration companion to the earlier Facebook-style and X-style UI prototypes. It is a responsive web page and does not require installing a mobile app.

## Included
- Three original *Immigration* articles (same source as the earlier prototypes) for each selected condition: Neutral, POLAR_POS, POLAR_NEG.
- An editorial news home screen, identical-size previews for all articles, neutral grey image slots, CSS Media brand and internal article reader.
- Save and share actions (local demo only); no social profiles, reactions, reposts or comments in this news-site version.
- Tap full-article sentences to highlight or un-highlight, **exactly two highlights** required when enabled.
- Article-specific True/False attention check; quiz completion required when enabled, regardless of correctness.
- 10 seconds of visible time required by default; configurable (0–600s).
- Article back navigation preserves the feed scroll position and records incomplete visits; successful completion saves a separate session.
- Per-article event log and exportable JSON with visible and elapsed time, scroll progression, paragraph visibility, highlights, quiz answer, completion status and applied configuration. No server connection yet.
- All controls in the top-right hamburger menu: experiment condition, highlighting, quiz, minimum-time requirement and data export.

## Run
Open `css-media-news-web-preview.html` directly in a browser (standalone file), or run the editable React source using `npm install` then `npm run dev`. Use `npm run build` for static hosting.

No survey pages (Step 1 / post-exposure / Step 3), no actual server storage. The news preview is a temporary excerpt from the original article, not a validated Step 3 stimulus. Placeholder images can later be replaced by setting `article.imageUrl` in `src/prototype/immigrationArticles.json`.
