import React, { useEffect, useMemo, useRef, useState } from 'react';
import sourceArticles from './immigrationArticles.json';

const ARTICLE_TOPIC = 'IMMIGRATION';
const ARTICLE_TOPIC_LABEL = 'Immigration policy';
const CONDITIONS = [
  { value: 'NEUTRAL', label: 'Neutral' },
  { value: 'POLAR_POS', label: 'POLAR_POS' },
  { value: 'POLAR_NEG', label: 'POLAR_NEG' },
];
const DEMO_POST = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore.';
const ARTICLE_PREVIEW_WORDS = 35; // Visual placeholder rule: Step 3 preview text has NOT been validated.
const STORAGE_KEY = 'css-media-news-v1-interaction-log';
const DEFAULT_CONFIG = { highlightEnabled: true, quizEnabled: true, minimumTimeEnabled: true, minimumSeconds: 10 };
function loadLocalLog() {
  try { const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return { events: Array.isArray(data.events) ? data.events : [], sessions: Array.isArray(data.sessions) ? data.sessions : [] };
  } catch { return { events: [], sessions: [] }; }
}
function articleSentences(paragraph) {
  // Mask common abbreviations so mobile browsers do not treat e.g. 'U.S.' as a complete sentence.
  const masked = paragraph.replace(/\bU\.S\./g, 'U§S§').replace(/\bU\.K\./g, 'U§K§');
  const unmask = s => s.replace(/U§S§/g,'U.S.').replace(/U§K§/g,'U.K.');
  if (typeof Intl !== 'undefined' && Intl.Segmenter) {
    return Array.from(new Intl.Segmenter('en', { granularity: 'sentence' }).segment(masked), entry => unmask(entry.segment.trim())).filter(Boolean);
  }
  return masked.match(/[^.!?]+(?:[.!?]+["'’”)]*|$)/g)?.map(s => unmask(s.trim())).filter(Boolean) || [paragraph];
}


function Icon({ name, size = 21, filled = false, strokeWidth = 1.9 }) {
  const shared = { fill: filled ? 'currentColor' : 'none', stroke: 'currentColor', strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    home: filled ? <path d="m3 11 9-8 9 8v10h-7v-7h-4v7H3z"/> : <><path d="m3 11 9-8 9 8v10h-7v-7h-4v7H3z"/></>,
    users: <><circle cx="8" cy="8" r="3"/><path d="M2 21v-2a6 6 0 0 1 12 0v2M16 5a3 3 0 0 1 0 6M16 14a6 6 0 0 1 6 6v1"/></>,
    video: <><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m10 9 5 3-5 3z"/></>,
    heart: <><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1.1L12 21l7.8-7.5 1.1-1.1a5.5 5.5 0 0 0-.1-7.8z"/></>,
    repost: <><path d="m3 7 3-3 3 3M6 4v12a3 3 0 0 0 3 3h2M21 17l-3 3-3-3M18 20V8a3 3 0 0 0-3-3h-2"/></>,
    chart: <><path d="M3 20V12M8 20V7M13 20v-4M18 20V4M1 20h22"/></>,
    mail: <><rect x="2" y="5" width="20" height="14" rx="2"/><path d="m3 7 9 7 9-7"/></>,
    feather: <><path d="M20 3c-8 0-13 5-13 13v5M7 16l9-9M3 21h13"/></>,
    thumbs: <><path d="M7 10v11H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM7 10l5-7c1-1 3-.4 3 1l-1 6h6a2 2 0 0 1 2 2l-1.5 7a3 3 0 0 1-3 2H7"/></>,
    comment: <><path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 9.3 9.3 0 0 1-4-.9L3 21l1.6-4.6A8.5 8.5 0 1 1 21 11.5z"/></>,
    share: <><path d="M12 16V3m0 0L7 8m5-5 5 5M4 13v6a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-6"/></>,
    arrowLeft: <><path d="m15 18-6-6 6-6M9 12h12"/></>,
    close: <><path d="M18 6 6 18M6 6l12 12"/></>,
    more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
    check: <><path d="m4 12 5 5L20 6"/></>,
    link: <><path d="M10 13a5 5 0 0 0 7.1 0l3-3A5 5 0 0 0 13 2.9l-1.6 1.6M14 11a5 5 0 0 0-7.1 0l-3 3A5 5 0 0 0 11 21.1l1.6-1.6"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-5-5-8 10"/></>,
    globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c6 5 6 13 0 18M12 3c-6 5-6 13 0 18"/></>,
    refresh: <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3"/></>,
    external: <><path d="M14 4h6v6M10 14 20 4M20 14v6H4V4h6"/></>,
    chevron: <><path d="m9 18 6-6-6-6"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></>,
    bookmark: <><path d="M5 3h14v18l-7-5-7 5z"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" focusable="false" {...shared}>{paths[name] || paths.info}</svg>;
}

function Avatar({ small = false }) {
  return <div className={`css-avatar ${small ? 'css-avatar--small' : ''}`} aria-label="CSS Media profile"><span>CSS</span></div>;
}

function ImageSlot({ article, className = '' }) {
  // To add photos later, set article.imageUrl (and optionally article.imageAlt).
  return <div className={`image-slot ${className}`}>
    {article.imageUrl ? <img src={article.imageUrl} alt={article.imageAlt || ''} /> : <div className="image-slot-placeholder"><Icon name="image" size={25}/><span>Image placeholder</span></div>}
  </div>;
}

function articlePreview(article) {
  // Extracted from the uploaded full article as a TEMPORARY preview, not validated stimuli.
  const tokens = (article.body?.[0] || '').trim().split(/\s+/);
  return tokens.length > ARTICLE_PREVIEW_WORDS ? `${tokens.slice(0, ARTICLE_PREVIEW_WORDS).join(' ')}…` : tokens.join(' ');
}

function BottomSheet({ title, onClose, children }) {
  return <div className="sheet-backdrop" onMouseDown={(event) => {if (event.target === event.currentTarget) onClose();}}>
    <div className="bottom-sheet" role="dialog" aria-modal="true" aria-label={title}>
      <div className="sheet-grabber" />
      <div className="sheet-heading"><strong>{title}</strong><button className="icon-plain" onClick={onClose} aria-label="Close"><Icon name="close"/></button></div>
      {children}
    </div>
  </div>;
}

function StoryCard({ article, index, read, saved, onOpen, onBookmark, onShare }) {
  return <article className="news-story" aria-label={`Story ${index + 1}: ${article.title}`}>
    <button type="button" className="news-story-link" onClick={()=>onOpen(article)} aria-label={`Read full article: ${article.title}`}>
      <div className="news-story-copy">
        <div className="news-story-meta">IMMIGRATION <span className="news-meta-dot">·</span> NEWS</div>
        <h2>{article.title}</h2>
        <p>{articlePreview(article)}</p>
      </div>
      <ImageSlot article={article} className="news-story-image" />
    </button>
    <div className="news-story-tools">
      <span className="news-story-identity">CSS Media <span className="news-meta-dot">·</span> Article {index+1} of 3</span>
      <div className="news-story-actions">
        {read && <span className="news-read-chip"><Icon name="check" size={12}/> Read</span>}
        <button aria-label={saved?'Remove bookmark':'Save article'} aria-pressed={saved} title={saved?'Remove saved article':'Save article'} className={saved?'news-saved':''} onClick={()=>onBookmark(article.id)}><Icon name="bookmark" size={19} filled={saved}/></button>
        <button aria-label="Share article" title="Share article" onClick={()=>onShare('share',article)}><Icon name="share" size={19}/></button>
      </div>
    </div>
  </article>;
}

function ArticleReader({ article, config, selectedHighlights, onHighlightChange, quizAnswer, onQuizSubmit, read, onFinalize, onArticleEvent }) {
  const scrollRef = useRef(null);
  const paragraphRefs = useRef([]);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [visibleSeconds, setVisibleSeconds] = useState(0);
  const [highlightNotice, setHighlightNotice] = useState('');
  const startedRef = useRef(new Date().toISOString());
  const startedPerfRef = useRef(performance.now());
  const lastPerfRef = useRef(performance.now());
  const countedVisibleRef = useRef(document.visibilityState === 'visible');
  const metricsRef = useRef({ visibleMs:0, scrollEventCount:0, maxScrollPercent:0, scrollSamples:[{tMs:0,scrollTop:0,scrollPercent:0,direction:'start'}], lastScrollTop:0, firstVisibleParagraphs:{}, visibilityTransitions:[] });
  const finalizedRef = useRef(false);
  const previousSessionMs = 0; // Completion timer applies to the current opening of an article.
  const targetSeconds = Math.max(0, Number(config.minimumSeconds) || 0);
  const sentences = useMemo(() => article.body.map(articleSentences), [article.id]);
  const highlights = selectedHighlights || [];
  const submitted = Boolean(quizAnswer);
  const highlightDone = !config.highlightEnabled || highlights.length === 2;
  const quizDone = !config.quizEnabled || submitted;
  const timeDone = !config.minimumTimeEnabled || visibleSeconds >= targetSeconds;
  const canFinish = highlightDone && quizDone && timeDone;

  function tickTime() {
    const now = performance.now();
    if (countedVisibleRef.current) metricsRef.current.visibleMs += Math.max(0, now - lastPerfRef.current);
    lastPerfRef.current = now;
    countedVisibleRef.current = document.visibilityState === 'visible';
    setVisibleSeconds(Math.floor((previousSessionMs + metricsRef.current.visibleMs) / 1000));
  }
  function recordScroll(force = false) {
    const el = scrollRef.current;
    if (!el) return;
    const m = metricsRef.current;
    const range = Math.max(0, el.scrollHeight - el.clientHeight);
    const pct = range ? 100 * el.scrollTop / range : 100;
    const lastSample = m.scrollSamples[m.scrollSamples.length - 1];
    const elapsed = Math.round(performance.now() - startedPerfRef.current);
    m.maxScrollPercent = Math.max(m.maxScrollPercent, pct);
    const direction = el.scrollTop > m.lastScrollTop ? 'down' : el.scrollTop < m.lastScrollTop ? 'up' : 'still';
    m.lastScrollTop = el.scrollTop;
    if (force || elapsed - lastSample.tMs >= 450 || Math.abs(pct - lastSample.scrollPercent) >= 10) {
      if (m.scrollSamples.length < 1000) m.scrollSamples.push({ tMs: elapsed, scrollTop: Math.round(el.scrollTop), scrollPercent: Math.round(pct*10)/10, direction });
    }
  }
  function handleScroll() {metricsRef.current.scrollEventCount++;recordScroll();}
  useEffect(() => {
    onArticleEvent('article_open', article.id, {sessionStartedAt:startedRef.current, configuration:{...config}});
    const interval = setInterval(tickTime, 200);
    const visibilityChanged = () => {
      tickTime();
      metricsRef.current.visibilityTransitions.push({tMs:Math.round(performance.now()-startedPerfRef.current),state:document.visibilityState});
    };
    document.addEventListener('visibilitychange', visibilityChanged);
    let observer;
    if ('IntersectionObserver' in window && scrollRef.current) {
      observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio >= 0.15) {
          const idx = entry.target.dataset.paragraph;
          const seen = metricsRef.current.firstVisibleParagraphs;
          if (!Object.prototype.hasOwnProperty.call(seen,idx)) seen[idx] = Math.round(performance.now()-startedPerfRef.current);
        }
      }), {root:scrollRef.current,threshold:[0.15]});
      paragraphRefs.current.forEach(p=>p&&observer.observe(p));
    }
    return () => { clearInterval(interval);document.removeEventListener('visibilitychange', visibilityChanged);observer?.disconnect(); };
  }, [article.id]);
  function toggleHighlight(key, text, paragraphIndex, sentenceIndex) {
    const found = highlights.some(item=>item.key===key);
    if (!found && highlights.length>=2) {setHighlightNotice('Two sentences are already selected. Tap one to remove it before choosing another.');return;}
    const next = found ? highlights.filter(item=>item.key!==key) : [...highlights, {key, text, paragraphIndex, sentenceIndex}];
    setHighlightNotice('');
    onHighlightChange(article.id, next, { action:found?'remove':'add',key,text,paragraphIndex,sentenceIndex });
  }
  function finish(complete) {
    if (finalizedRef.current) return;
    if (complete && !canFinish) return;
    tickTime();
    recordScroll(true);
    finalizedRef.current = true;
    const m = metricsRef.current;
    onFinalize({
      articleId: article.id, title: article.title, condition: article.condition,
      startedAt: startedRef.current, endedAt:new Date().toISOString(),
      elapsedMs:Math.round(performance.now()-startedPerfRef.current),
      visibleMs:Math.round(m.visibleMs),
      maxScrollPercent:Math.round(m.maxScrollPercent*10)/10,
      scrollEventCount:m.scrollEventCount,
      scrollSamples:m.scrollSamples,
      paragraphFirstVisibleMs:m.firstVisibleParagraphs,
      visibilityTransitions:m.visibilityTransitions,
      highlights:highlights.map(item=>({...item})),
      quiz:quizAnswer ? {...quizAnswer} : null,
      configuration:{...config},
      status:complete?'completed':'closed_early'
    }, complete);
  }
  return <div className="reader" role="region" aria-label="Full news article">
    <header className="news-reader-header">
      <button className="news-reader-back" aria-label="Close article without completing" title="Return to stories without marking this article as read" onClick={()=>finish(false)}><Icon name="arrowLeft" size={22}/><span>Stories</span></button>
      <span className="news-reader-brand">CSS <span>Media</span></span>
      <button className="news-reader-more" title="Article information" aria-label="Article information" onClick={()=>onArticleEvent('reader_more_tap',article.id)}><Icon name="more" size={22}/></button>
    </header>
    <div className="reader-scroll" ref={scrollRef} onScroll={handleScroll}>

      <div className="reader-article">
        <div className="reader-kicker">WORLD <span>·</span> {ARTICLE_TOPIC_LABEL.toUpperCase()}</div>
        <h1>{article.title}</h1>
        <div className="reader-byline">By CSS Media Newsroom</div>
        <div className="reader-divider"/>
        <ImageSlot article={article} className="reader-image" />
        <div className="reader-image-caption">Illustration placeholder. Photo to be selected.</div>
        {config.highlightEnabled && <div className="highlight-instruction"><div className="highlight-instruction-title"><Icon name="bookmark" size={17}/> While reading</div><p>Please highlight <strong>two sentences</strong> that you consider most important in this article. Tap a sentence to highlight it; tap again to remove the highlight.</p><div className="highlight-counter">{highlights.length} of 2 sentences highlighted</div></div>}
        <div className={`reader-body ${config.highlightEnabled?'reader-body--interactive':''}`}>
          {article.body.map((paragraph,idx)=><p key={idx} data-paragraph={idx} ref={node=>{paragraphRefs.current[idx]=node;}}>
            {config.highlightEnabled ? sentences[idx].map((sentence,sIndex)=> {
              const key=`${idx}:${sIndex}`;
              const chosen=highlights.some(item=>item.key===key);
              return <React.Fragment key={key}><span role="button" tabIndex={0} className={`highlight-sentence ${chosen?'highlight-sentence--selected':''}`} aria-pressed={chosen} aria-label={`${chosen?'Remove highlight from':'Highlight'} sentence: ${sentence}`} onClick={()=>toggleHighlight(key,sentence,idx,sIndex)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggleHighlight(key,sentence,idx,sIndex);}}}>{sentence}</span>{' '}</React.Fragment>;
            }) : paragraph}
          </p>)}
        </div>
        {config.highlightEnabled && highlightNotice && <p className="highlight-notice" role="status">{highlightNotice}</p>}
        {config.quizEnabled && <section className="quiz-panel" aria-label="Article attention check">
          <div className="quiz-eyebrow">ATTENTION CHECK</div>
          <h2>Quick question</h2>
          <p className="quiz-intro">Based on the article you just read, is the following statement true or false?</p>
          <p className="quiz-statement">{article.attentionCheck.statement}</p>
          {submitted ? <div className="quiz-confirmation" role="status"><Icon name="check" size={18}/> Answer recorded. Thank you.</div> : <>
            <div className="quiz-options" role="group" aria-label="Choose true or false">
              {[true,false].map(value=><button type="button" key={String(value)} className={`quiz-option ${selectedAnswer===value?'quiz-option--selected':''}`} aria-pressed={selectedAnswer===value} onClick={()=>setSelectedAnswer(value)}><span className="quiz-radio"/>{value?'True':'False'}</button>)}
            </div>
            <button className="quiz-submit" disabled={selectedAnswer===null} onClick={()=>onQuizSubmit(article.id,selectedAnswer,article.attentionCheck.correctAnswer)}>Submit answer</button>
          </>}
        </section>}
        <div className="read-done">
          <div className="read-done-icon"><Icon name="check" size={22}/></div>
          <h3>{read?'Article already completed':'Ready to finish?'}</h3>
          <p>Complete the enabled requirements below to return to the news feed and mark the article as read.</p>
          <div className="completion-checklist">
            {config.highlightEnabled && <div className={highlightDone?'complete':''}><Icon name={highlightDone?'check':'info'} size={16}/> Highlight two sentences <strong>{highlights.length}/2</strong></div>}
            {config.quizEnabled && <div className={quizDone?'complete':''}><Icon name={quizDone?'check':'info'} size={16}/> Submit your answer <strong>{quizDone?'Done':'Pending'}</strong></div>}
            {config.minimumTimeEnabled && <div className={timeDone?'complete':''}><Icon name={timeDone?'check':'info'} size={16}/> Time on article <strong>{visibleSeconds}/{targetSeconds}s</strong></div>}
            {!config.highlightEnabled&&!config.quizEnabled&&!config.minimumTimeEnabled && <div className="complete"><Icon name="check" size={16}/> No additional requirements</div>}
          </div>
          <button className="primary-action" disabled={!canFinish} onClick={()=>finish(true)}>Back to news feed</button>
          <p className="completion-footnote">Time counts while this page is visible. Closing with X saves an incomplete visit but does not mark the article as read.</p>
        </div>
      </div>
      <div className="reader-foot">© CSS Media</div>
    </div>
  </div>;
}

export default function NewsPrototype() {
  const [condition,setCondition]=useState('NEUTRAL');
  const [quizAnswers,setQuizAnswers]=useState({});
  const [activeArticle,setActiveArticle]=useState(null);
  const [readIds,setReadIds]=useState([]);
  const [likedIds,setLikedIds]=useState([]);
  const [repostedIds,setRepostedIds]=useState([]);
  const [bookmarkedIds,setBookmarkedIds]=useState([]);
  const [comments,setComments]=useState({});
  const [commentDraft,setCommentDraft]=useState('');
  const [sheet,setSheet]=useState(null);
  const [toast,setToast]=useState('');
  const [config,setConfig]=useState(DEFAULT_CONFIG);
  const [highlightSelections,setHighlightSelections]=useState({});
  const [storedLog,setStoredLog]=useState(loadLocalLog);
  const [sessions,setSessions]=useState(()=>storedLog.sessions);
  const [events,setEvents]=useState(()=>storedLog.events);
  const feedRef=useRef(null);
  const lastFeedScrollRef=useRef(0);
  const eventsRef=useRef(storedLog.events);
  useEffect(()=>{
    try { localStorage.setItem(STORAGE_KEY,JSON.stringify({events,sessions})); } catch { /* Browser storage may be unavailable in private/file mode. */ }
  },[events,sessions]);
  const articles=useMemo(()=>sourceArticles.filter((a)=>a.condition===condition).sort((a,b)=>a.coreId.localeCompare(b.coreId)),[condition]);
  const readCount=articles.filter((article)=>readIds.includes(article.id)).length;
  const visibleArticle=articles.find((article)=>article.id===activeArticle);
  const allRead=readCount===articles.length && articles.length===3;

  function logEvent(type,articleId=null,detail={}) {
    const entry={event:type,articleId,topic:ARTICLE_TOPIC,condition,at:new Date().toISOString(),...detail};
    eventsRef.current=[...eventsRef.current,entry];
    setEvents(eventsRef.current);
  }
  function resetDemo(nextCondition=condition) {
    setCondition(nextCondition);setActiveArticle(null);setSheet(null);
    setReadIds([]);setQuizAnswers({});setLikedIds([]);setRepostedIds([]);setBookmarkedIds([]);setComments({});setCommentDraft('');setToast('');
    setHighlightSelections({});logEvent('prototype_reset',null,{nextCondition});
    if(feedRef.current)feedRef.current.scrollTop=0;
  }
  function openArticle(article) {
    lastFeedScrollRef.current=feedRef.current?.scrollTop||0;
    setSheet(null);setActiveArticle(article.id);
  }
  function closeArticle() { setActiveArticle(null); logEvent('return_to_feed',activeArticle); }
  function onFinalizeArticle(summary,completed){
    const item={...summary,recordId:`${summary.articleId}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`};
    setSessions(previous=>[...previous,item]);
    logEvent('article_session_saved',summary.articleId,{status:summary.status,visibleMs:summary.visibleMs,maxScrollPercent:summary.maxScrollPercent,highlightCount:summary.highlights.length,quizSubmitted:!!summary.quiz});
    if(completed){setReadIds(prev=>prev.includes(summary.articleId)?prev:[...prev,summary.articleId]);logEvent('article_mark_read',summary.articleId);}
    closeArticle();
  }
  function updateHighlights(id,next,detail){setHighlightSelections(prev=>({...prev,[id]:next}));logEvent(`highlight_${detail.action}`,id,detail);}
  function updateSetting(key,value){setConfig(prev=>({...prev,[key]:value}));setReadIds([]);setQuizAnswers({});setHighlightSelections({});logEvent('configuration_changed',null,{setting:key,value});}
  function clearLogs(){if(!window.confirm('Clear all locally stored article sessions and event logs?'))return;eventsRef.current=[];setEvents([]);setSessions([]);try{localStorage.removeItem(STORAGE_KEY);}catch{}showToast('Local logs cleared');}
  useEffect(()=>{if(!activeArticle&&feedRef.current)feedRef.current.scrollTop=lastFeedScrollRef.current;},[activeArticle]);
  function showToast(message){setToast(message);window.setTimeout(()=>setToast(''),2600);}
  function openSheet(kind,article){setSheet({kind,article});setCommentDraft('');logEvent(`${kind}_open`,article?.id);}
  function toggleLike(id){setLikedIds(previous=>previous.includes(id)?previous.filter(x=>x!==id):[...previous,id]);logEvent('like_toggle',id);}
  function toggleBookmark(id){setBookmarkedIds(previous=>previous.includes(id)?previous.filter(x=>x!==id):[...previous,id]);logEvent('bookmark_toggle',id);}
  function submitQuiz(id, answer, correctAnswer){if(quizAnswers[id])return;setQuizAnswers(previous=>({...previous,[id]:{answer,correct:answer===correctAnswer}}));logEvent('attention_check_submit',id,{answer,correct:answer===correctAnswer});}
  function addComment(){if(!commentDraft.trim()||!sheet?.article)return;const id=sheet.article.id;setComments(prev=>({...prev,[id]:[...(prev[id]||[]),commentDraft.trim()]}));setCommentDraft('');logEvent('comment_add',id);}
  function toggleRepost(id){setRepostedIds(previous=>previous.includes(id)?previous.filter(x=>x!==id):[...previous,id]);logEvent('repost_toggle',id);setSheet(null);showToast(repostedIds.includes(id)?'Repost removed (demo only)':'Reposted privately in this demo');}
  function copyLink(id){const link=`${window.location.origin}${window.location.pathname}#article=${encodeURIComponent(id)}`;if(navigator.clipboard?.writeText){navigator.clipboard.writeText(link).then(()=>showToast('Demo article link copied')).catch(()=>showToast('Could not copy link'));} else showToast('Clipboard unavailable in this browser');logEvent('copy_link',id);setSheet(null);}
  function downloadEvents(){const payload={prototype:'CSS Media mobile news website v1',exportedAt:new Date().toISOString(),note:'Local demonstration only. No data has been sent to a server.',condition,configuration:config,articleSessions:sessions,events:eventsRef.current};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='css-media-news-web-demo-events.json';a.click();URL.revokeObjectURL(url);}

  return <div className="prototype-page">
    <div className="prototype-layout">
      <div className="mobile-stage">
        <div className="fb-phone news-phone">
          <header className="news-site-header">
            <div className="news-brand-block">
              <div className="news-brand">CSS <span>Media</span></div>
              <div className="news-brand-tagline">NEWS · REPORTING · CONTEXT</div>
            </div>
            <div className="news-site-actions">
              <button aria-label="Search" title="Search" onClick={()=>openSheet('search',null)}><Icon name="search" size={22}/></button>
              <button aria-label="Experimental condition settings" title="Prototype settings" onClick={()=>openSheet('settings',null)}><Icon name="menu" size={23}/></button>
            </div>
          </header>
          <div className="news-site-nav"><strong>LATEST</strong><span>IMMIGRATION POLICY</span></div>
          <div className="task-strip"><div className="task-strip-top"><span>NEWS READING</span><span>{readCount} of 3 read</span></div><div className="task-progress"><div style={{width:`${readCount/3*100}%`}}/></div><p>Open all three articles and complete the enabled reading tasks.</p></div>
          <main className="feed-scroll news-feed-scroll" ref={feedRef} aria-label="News feed" onScroll={(e)=>{lastFeedScrollRef.current=e.currentTarget.scrollTop;}}>
            <div className="feed-background news-feed-background">
              <div className="news-feed-heading"><p className="news-feed-eyebrow">CSS MEDIA · WORLD</p><h1>Latest stories</h1><p>Immigration policy</p><div className="news-heading-rule"/></div>
              {articles.map((article,i)=><StoryCard key={article.id} article={article} index={i} read={readIds.includes(article.id)} saved={bookmarkedIds.includes(article.id)} onOpen={openArticle} onBookmark={toggleBookmark} onShare={openSheet}/>)}
              <div className={`end-card ${allRead?'end-card--complete':''}`}><div className="end-card-icon"><Icon name={allRead?'check':'bookmark'} size={24}/></div><strong>{allRead?'All three articles read':'End of news list'}</strong><p>{allRead?'The reading task is complete. In the full experiment, the post-exposure questionnaire would appear next.':'Open each article, complete the reading requirements, then return to the feed.'}</p>{allRead&&<button className="primary-action" onClick={()=>showToast('End of prototype. Surveys are intentionally excluded.')}>Continue <Icon name="chevron" size={16}/></button>}</div>
            </div>
          </main>

          {visibleArticle&&<ArticleReader key={visibleArticle.id} article={visibleArticle} config={config} selectedHighlights={highlightSelections[visibleArticle.id] || []} onHighlightChange={updateHighlights} read={readIds.includes(visibleArticle.id)} onFinalize={onFinalizeArticle} onArticleEvent={logEvent} quizAnswer={quizAnswers[visibleArticle.id]} onQuizSubmit={submitQuiz}/>}
          {sheet&&<BottomSheet title={sheet.kind==='comments'?'Comments':sheet.kind==='share'?'Share this article':sheet.kind==='search'?'Search':sheet.kind==='notifications'?'Notifications':sheet.kind==='navigation'?'Section unavailable':sheet.kind==='settings'?'Prototype settings':'Post information'} onClose={()=>setSheet(null)}>
            {sheet.kind==='comments'&&<div className="comments-content"><div className="comments-list">{(comments[sheet.article.id]||[]).length===0?<div className="empty-state"><Icon name="comment" size={30}/><strong>No replies yet</strong><span>Be the first to comment. Replies are stored only in this demo session.</span></div>:(comments[sheet.article.id]||[]).map((c,i)=><div className="single-comment" key={i}><div className="comment-avatar">You</div><div><strong>Demo participant</strong><p>{c}</p></div></div>)}</div><form onSubmit={e=>{e.preventDefault();addComment();}} className="comment-composer"><input aria-label="Write a comment" placeholder="Write a comment..." value={commentDraft} onChange={e=>setCommentDraft(e.target.value)} maxLength={500}/><button disabled={!commentDraft.trim()} type="submit">Post</button></form></div>}
            {sheet.kind==='share'&&<div className="share-options"><button onClick={()=>copyLink(sheet.article.id)}><Icon name="link"/><span>Copy demo article link</span></button><p>Sharing is simulated for this UI demonstration. No content is posted externally.</p></div>}
            {sheet.kind==='settings'&&<div className="settings-content">
              <div className="settings-note"><Icon name="info" size={18}/><span>Research prototype settings. These controls are for reviewing the UI, not for study participants.</span></div>
              <label className="settings-label" htmlFor="condition-select">Experimental condition</label>
              <select id="condition-select" value={condition} onChange={e=>resetDemo(e.target.value)}>{CONDITIONS.map(c=><option key={c.value} value={c.value}>{c.label}</option>)}</select>
              <p className="settings-detail">The news list always contains three immigration articles. Changing conditions resets reading progress and saved stories.</p>
              <div className="settings-section-title">Reading requirements</div>
              <label className="settings-switch-row"><span><strong>Sentence highlighting</strong><small>Require two highlighted sentences per article</small></span><input type="checkbox" checked={config.highlightEnabled} onChange={e=>updateSetting('highlightEnabled',e.target.checked)}/></label>
              <label className="settings-switch-row"><span><strong>Attention check quiz</strong><small>Require an answer before completion</small></span><input type="checkbox" checked={config.quizEnabled} onChange={e=>updateSetting('quizEnabled',e.target.checked)}/></label>
              <label className="settings-switch-row"><span><strong>Minimum article time</strong><small>Count time only when the article is visible</small></span><input type="checkbox" checked={config.minimumTimeEnabled} onChange={e=>updateSetting('minimumTimeEnabled',e.target.checked)}/></label>
              <label className="settings-label settings-number-label" htmlFor="minimum-seconds">Minimum visible time (seconds)</label>
              <input id="minimum-seconds" className="settings-number" type="number" min="0" max="600" step="1" value={config.minimumSeconds} disabled={!config.minimumTimeEnabled} onChange={e=>updateSetting('minimumSeconds',Math.max(0,Math.min(600,Math.floor(Number(e.target.value)||0))))}/>
              <p className="settings-detail">Changing a requirement clears reading progress, highlights, and quiz answers. Previously saved interaction logs remain available for export.</p>
              <div className="settings-progress"><span>Reading progress</span><strong>{readCount} / 3</strong></div>
              <button className="settings-action" onClick={()=>resetDemo()}><Icon name="refresh" size={17}/> Reset demonstration</button>
              <div className="settings-progress"><span>Saved article visits</span><strong>{sessions.length}</strong></div>
              <button className="settings-action" onClick={downloadEvents}><Icon name="external" size={17}/> Export article sessions + event log (JSON)</button>
              <button className="settings-action settings-action--danger" onClick={clearLogs}>Clear saved logs</button>
              <p className="settings-footnote">Article text and true/false attention checks are taken from the uploaded Step 2 source data. Preview excerpts are temporary placeholders and have not been validated.</p>
            </div>}
            {sheet.kind==='search'&&<div className="sheet-simple"><Icon name="search"/><p>Search is not part of this three-article news website demonstration.</p></div>}
            {sheet.kind==='notifications'&&<div className="sheet-simple"><Icon name="bell"/><p>No notifications.</p></div>}
            {sheet.kind==='navigation'&&<div className="sheet-simple"><Icon name="info"/><p>This prototype contains the three assigned news articles only.</p></div>}
            {(sheet.kind==='about'||sheet.kind==='info')&&<div className="sheet-simple"><Icon name="info"/><p>CSS Media is a fictional publisher used for a mobile news website research UI demonstration. All demonstration interactions stay local to your browser; no data is uploaded.</p></div>}
          </BottomSheet>}
          {toast&&<div className="toast" role="status">{toast}</div>}
        </div>
      </div>
    </div>
  </div>;
}
