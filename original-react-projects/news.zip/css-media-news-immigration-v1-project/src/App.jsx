import React from 'react';
import NewsPrototype from './prototype/NewsPrototype';
import './prototype/news-prototype.css';

export default function App(){ return <NewsPrototype/>; }
