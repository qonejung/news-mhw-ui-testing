# Flow and question update

- Step 1 affect/psychological questions are renumbered 1–4 and use participant-facing wording only.
- Step 2 topic selection is now embedded in the article-reading introduction, directly above `Start Article 1`, with no question number.
- Step 2 post-reading questions are numbered 1–5 and mirror the Step 1 wording for questions 1–4.
- Step 4 is a single-page survey. Background questions are numbered 1–9 and the selected-topic stance/importance questions are numbered 10–11.
- Existing test mode, article timing, attention checks, random assignment, and Step 3 behavior are unchanged.
