# Layout and Step 1 wording update

This version builds on the Step 1 + Step 2 implementation and applies the requested layout/readability changes.

## Changes

- Main experiment content now uses 80% of viewport width on desktop, 92% on small/medium screens, and 94% on narrow screens.
- Removed the previous `max-w-3xl` cap from Step 1, Step 2, and the Step 3 placeholder.
- Increased survey/interface typography by one Tailwind size step in the main question, instruction, scale, and button elements.
- Increased article body text from 16px to 18px for readability.
- Reworked Likert scales so they no longer rely on a fixed minimum width or horizontal scrolling.
- Short endpoint/midpoint labels now appear beneath the numeric scale in a three-anchor layout.
- Reworded Question 11 as a bipolar policy-position item for each selected topic.

## Question 11 wording

### Immigration
Which of the following positions comes closer to your view on immigration policy?

- 1: Strongly favor allowing more immigration
- 4: Neither / about in the middle
- 7: Strongly favor restricting immigration

### Climate
Which of the following positions comes closer to your view on government regulations aimed at addressing climate change?

- 1: Strongly favor stronger regulations
- 4: Neither / about in the middle
- 7: Strongly favor less stringent regulations

### Gender equality and LGBTQ+ rights
Which of the following positions comes closer to your view on legal protections and institutional support for gender minorities and LGBTQ+ rights?

- 1: Strongly favor expanding protections and support
- 4: Neither / about in the middle
- 7: Strongly favor reducing protections and support

## Note

A local build was not run in the artifact environment because dependency installation did not complete there. Run `npm install` (if needed) and `npm run dev` in your local project to inspect the responsive layout.
