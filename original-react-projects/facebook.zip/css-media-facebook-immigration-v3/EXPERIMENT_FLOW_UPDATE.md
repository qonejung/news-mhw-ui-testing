# Experiment flow update

Current participant-facing sequence:

1. Affective & Psychological State
   - Former Questions 13-16 only.
   - No participant-facing "Baseline" wording.
2. News Article Reading
   - Question 10 (most important topic) is asked first.
   - The topic determines the article topic.
   - After the topic is submitted, the participant is assigned once to POLAR_POS, POLAR_NEG, or NEUTRAL.
   - Three Step 2 articles matching topic × assigned condition are shown.
3. News Article Choice
   - Two choice sets are shown.
   - One set comes from the participant-selected topic.
   - One set comes from one randomly selected unchosen topic.
   - One core (04/05/06) is randomly selected for each topic.
   - Each set contains NEUTRAL, POLAR_POS, and POLAR_NEG previews in randomized positions.
   - The order of the two topic sets is randomized.
4. Background Information
   - Former Questions 1-9 plus topic-specific Questions 11-12.
   - Questions 11-12 use the topic selected in Step 2.
5. Complete
