# Step 2 implementation

This version implements the revised three-article exposure flow.

- Step 1 Q10 determines the topic: `IMMIGRATION`, `CLIMATE`, or `GENDER_LGBTQ`.
- At Step 1 completion, the participant is assigned once to `POLAR_POS`, `POLAR_NEG`, or `NEUTRAL`.
- Step 2 filters the 27-article stimulus set by topic and assigned condition, yielding exactly three articles.
- The order of those three articles is randomized once when Step 2 mounts.
- Participants read all three articles without intervening questions.
- Time spent on each article and presentation order are recorded.
- After all three articles, participants complete SAM, STAI-6, Stress NRS-11, I-PANAS-SF, one overall perceived-polarization rating, and one True/False attention check for each article.
- The SAM images are placeholders and can be replaced later.
- STAI-6 response labels remain the same development defaults used in Step 1 and should be checked before deployment.
- Step 3 is still a placeholder.
