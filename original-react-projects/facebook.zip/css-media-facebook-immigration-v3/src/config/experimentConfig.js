// src/config/experimentConfig.js
// Development switches kept in one place so the pilot build can be tightened
// without changing the survey components themselves.
export const TEST_MODE = true;

// While TEST_MODE is true, the Step 2 topic-selection question is preselected
// so the development flow can be advanced quickly. In the final build, set
// TEST_MODE to false and no topic will be preselected.
export const TEST_DEFAULT_TOPIC = 'IMMIGRATION';

// Minimum time each Step 2 article must remain open before Continue can unlock.
// The participant must also reach the end of the article.
export const ARTICLE_CONTINUE_DELAY_SECONDS = 3;

// Number of words shown from each Step 3 article body in the preview card.
export const STEP3_PREVIEW_WORD_LIMIT = 70;
