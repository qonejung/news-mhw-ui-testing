import React, { useEffect, useMemo, useRef, useState } from 'react';
import sourceArticles from './immigrationArticles.json';

const ARTICLE_TOPIC = 'IMMIGRATION';
const ARTICLE_TOPIC_LABEL = 'Immigration policy';
const CONDITIONS = [
  { value: 'NEUTRAL', label: 'Neutral' },
  { value: 'POLAR_POS', label: 'POLAR_POS' },
  { value: 'POLAR_NEG', label: 'POLAR_NEG' },
];
const DEMO_POST = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore.';
const ARTICLE_PREVIEW_WORDS = 35; // Visual placeholder rule: Step 3 preview text has NOT been validated.
const STORAGE_KEY = 'css-media-facebook-v3-interaction-log';
const DEFAULT_CONFIG = { highlightEnabled: true, quizEnabled: true, minimumTimeEnabled: true, minimumSeconds: 10 };
function loadLocalLog() {
  try { const data = JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}');
    return { events: Array.isArray(data.events) ? data.events : [], sessions: Array.isArray(data.sessions) ? data.sessions : [] };
  } catch { return { events: [], sessions: [] }; }
}
function articleSentences(paragraph) {
  // Mask common abbreviations so mobile browsers do not treat e.g. 'U.S.' as a complete sentence.
  const masked = paragraph.replace(/\bU\.S\./g, 'U§S§').replace(/\bU\.K\./g, 'U§K§');
  const unmask = s => s.replace(/U§S§/g,'U.S.').replace(/U§K§/g,'U.K.');
  if (typeof Intl !== 'undefined' && Intl.Segmenter) {
    return Array.from(new Intl.Segmenter('en', { granularity: 'sentence' }).segment(masked), entry => unmask(entry.segment.trim())).filter(Boolean);
  }
  return masked.match(/[^.!?]+(?:[.!?]+["'’”)]*|$)/g)?.map(s => unmask(s.trim())).filter(Boolean) || [paragraph];
}


function Icon({ name, size = 21, filled = false, strokeWidth = 1.9 }) {
  const shared = { fill: filled ? 'currentColor' : 'none', stroke: 'currentColor', strokeWidth, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    menu: <><path d="M4 6h16M4 12h16M4 18h16"/></>,
    home: filled ? <path d="m3 11 9-8 9 8v10h-7v-7h-4v7H3z"/> : <><path d="m3 11 9-8 9 8v10h-7v-7h-4v7H3z"/></>,
    users: <><circle cx="8" cy="8" r="3"/><path d="M2 21v-2a6 6 0 0 1 12 0v2M16 5a3 3 0 0 1 0 6M16 14a6 6 0 0 1 6 6v1"/></>,
    video: <><rect x="3" y="5" width="18" height="14" rx="3"/><path d="m10 9 5 3-5 3z"/></>,
    thumbs: <><path d="M7 10v11H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zM7 10l5-7c1-1 3-.4 3 1l-1 6h6a2 2 0 0 1 2 2l-1.5 7a3 3 0 0 1-3 2H7"/></>,
    comment: <><path d="M21 11.5a8.5 8.5 0 0 1-9 8.5 9.3 9.3 0 0 1-4-.9L3 21l1.6-4.6A8.5 8.5 0 1 1 21 11.5z"/></>,
    share: <><path d="M13 5 21 12l-8 7v-5c-6 0-10 2-12 5 0-7 4-11 12-11z"/></>,
    arrowLeft: <><path d="m15 18-6-6 6-6M9 12h12"/></>,
    close: <><path d="M18 6 6 18M6 6l12 12"/></>,
    more: <><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>,
    check: <><path d="m4 12 5 5L20 6"/></>,
    link: <><path d="M10 13a5 5 0 0 0 7.1 0l3-3A5 5 0 0 0 13 2.9l-1.6 1.6M14 11a5 5 0 0 0-7.1 0l-3 3A5 5 0 0 0 11 21.1l1.6-1.6"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 16-5-5-8 10"/></>,
    globe: <><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c6 5 6 13 0 18M12 3c-6 5-6 13 0 18"/></>,
    refresh: <><path d="M20 7v5h-5M4 17v-5h5"/><path d="M5.6 9A7 7 0 0 1 18 6l2 6M4 12l2 6a7 7 0 0 0 12.4-3"/></>,
    external: <><path d="M14 4h6v6M10 14 20 4M20 14v6H4V4h6"/></>,
    chevron: <><path d="m9 18 6-6-6-6"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/></>,
    bookmark: <><path d="M5 3h14v18l-7-5-7 5z"/></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" focusable="false" {...shared}>{paths[name] || paths.info}</svg>;
}

function Avatar({ small = false }) {
  return <div className={`css-avatar ${small ? 'css-avatar--small' : ''}`} aria-label="CSS Media profile"><span>CSS</span></div>;
}

function ImageSlot({ article, className = '' }) {
  // To add photos later, set article.imageUrl (and optionally article.imageAlt).
  return <div className={`image-slot ${className}`}>
    {article.imageUrl ? <img src={article.imageUrl} alt={article.imageAlt || ''} /> : <div className="image-slot-placeholder"><Icon name="image" size={25}/><span>Image placeholder</span></div>}
  </div>;
}

function articlePreview(article) {
  // Extracted from the uploaded full article as a TEMPORARY preview, not validated stimuli.
  const tokens = (article.body?.[0] || '').trim().split(/\s+/);
  return tokens.length > ARTICLE_PREVIEW_WORDS ? `${tokens.slice(0, ARTICLE_PREVIEW_WORDS).join(' ')}…` : tokens.join(' ');
}

function BottomSheet({ title, onClose, children }) {
  return <div className="sheet-backdrop" onMouseDown={(event) => {if (event.target === event.currentTarget) onClose();}}>
    <div className="bottom-sheet" role="dialog" aria-modal="true" aria-label={title}>
      <div className="sheet-grabber" />
      <div className="sheet-heading"><strong>{title}</strong><button className="icon-plain" onClick={onClose} aria-label="Close"><Icon name="close"/></button></div>
      {children}
    </div>
  </div>;
}

function Post({ article, index, read, liked, reposted, commentCount, onOpen, onLike, onComment, onShare }) {
  return <article className="post" aria-label={`Post ${index+1}: ${article.title}`}>
    <div className="post-inner">
      <div className="post-author">
        <Avatar/>
        <div className="post-author-meta"><div className="post-author-title"><strong>CSS Media</strong></div><div className="post-date">Today · <Icon name="globe" size={12}/></div></div>
        <button className="post-more" title="Post information" onClick={()=>onShare('info',article)}><Icon name="more" size={22}/></button>
      </div>
      <p className="post-caption">{DEMO_POST}</p>
    </div>
    <button type="button" className="article-link-card" onClick={() => onOpen(article)} aria-label={`Read full article: ${article.title}`}>
      <ImageSlot article={article}/>
      <div className="article-link-copy">
        <div className="link-site">CSSMEDIA.EXAMPLE</div>
        <h2>{article.title}</h2>
        <p>{articlePreview(article)}</p>
        <div className="link-card-action"><span>Read full article</span><Icon name="chevron" size={15}/></div>
      </div>
    </button>
    <div className="post-inner">
      <div className="post-stats" aria-live="polite">
        <span>{liked ? '👍 1' : ''}</span>
        <span>{commentCount ? `${commentCount} comment${commentCount === 1 ? '' : 's'}` : ''}{reposted ? ` · 1 share` : ''}</span>
      </div>
      <div className="post-actions">
        <button className={liked ? 'is-active' : ''} aria-pressed={liked} onClick={()=>onLike(article.id)}><Icon name="thumbs" size={18} filled={liked}/><span>Like</span></button>
        <button onClick={()=>onComment(article.id)}><Icon name="comment" size={18}/><span>Comment</span></button>
        <button aria-pressed={reposted} onClick={()=>onShare('share',article)}><Icon name="share" size={18}/><span>Share</span></button>
      </div>
    </div>
    {read && <div className="post-read-status"><Icon name="check" size={13}/> Article marked as read</div>}
  </article>;
}

function ArticleReader({ article, config, selectedHighlights, onHighlightChange, quizAnswer, onQuizSubmit, read, onFinalize, onArticleEvent }) {
  const scrollRef = useRef(null);
  const paragraphRefs = useRef([]);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [visibleSeconds, setVisibleSeconds] = useState(0);
  const [highlightNotice, setHighlightNotice] = useState('');
  const startedRef = useRef(new Date().toISOString());
  const startedPerfRef = useRef(performance.now());
  const lastPerfRef = useRef(performance.now());
  const countedVisibleRef = useRef(document.visibilityState === 'visible');
  const metricsRef = useRef({ visibleMs:0, scrollEventCount:0, maxScrollPercent:0, scrollSamples:[{tMs:0,scrollTop:0,scrollPercent:0,direction:'start'}], lastScrollTop:0, firstVisibleParagraphs:{}, visibilityTransitions:[] });
  const finalizedRef = useRef(false);
  const previousSessionMs = 0; // Completion timer applies to the current opening of an article.
  const targetSeconds = Math.max(0, Number(config.minimumSeconds) || 0);
  const sentences = useMemo(() => article.body.map(articleSentences), [article.id]);
  const highlights = selectedHighlights || [];
  const submitted = Boolean(quizAnswer);
  const highlightDone = !config.highlightEnabled || highlights.length === 2;
  const quizDone = !config.quizEnabled || submitted;
  const timeDone = !config.minimumTimeEnabled || visibleSeconds >= targetSeconds;
  const canFinish = highlightDone && quizDone && timeDone;

  function tickTime() {
    const now = performance.now();
    if (countedVisibleRef.current) metricsRef.current.visibleMs += Math.max(0, now - lastPerfRef.current);
    lastPerfRef.current = now;
    countedVisibleRef.current = document.visibilityState === 'visible';
    setVisibleSeconds(Math.floor((previousSessionMs + metricsRef.current.visibleMs) / 1000));
  }
  function recordScroll(force = false) {
    const el = scrollRef.current;
    if (!el) return;
    const m = metricsRef.current;
    const range = Math.max(0, el.scrollHeight - el.clientHeight);
    const pct = range ? 100 * el.scrollTop / range : 100;
    const lastSample = m.scrollSamples[m.scrollSamples.length - 1];
    const elapsed = Math.round(performance.now() - startedPerfRef.current);
    m.maxScrollPercent = Math.max(m.maxScrollPercent, pct);
    const direction = el.scrollTop > m.lastScrollTop ? 'down' : el.scrollTop < m.lastScrollTop ? 'up' : 'still';
    m.lastScrollTop = el.scrollTop;
    if (force || elapsed - lastSample.tMs >= 450 || Math.abs(pct - lastSample.scrollPercent) >= 10) {
      if (m.scrollSamples.length < 1000) m.scrollSamples.push({ tMs: elapsed, scrollTop: Math.round(el.scrollTop), scrollPercent: Math.round(pct*10)/10, direction });
    }
  }
  function handleScroll() {metricsRef.current.scrollEventCount++;recordScroll();}
  useEffect(() => {
    onArticleEvent('article_open', article.id, {sessionStartedAt:startedRef.current, configuration:{...config}});
    const interval = setInterval(tickTime, 200);
    const visibilityChanged = () => {
      tickTime();
      metricsRef.current.visibilityTransitions.push({tMs:Math.round(performance.now()-startedPerfRef.current),state:document.visibilityState});
    };
    document.addEventListener('visibilitychange', visibilityChanged);
    let observer;
    if ('IntersectionObserver' in window && scrollRef.current) {
      observer = new IntersectionObserver(entries => entries.forEach(entry => {
        if (entry.isIntersecting && entry.intersectionRatio >= 0.15) {
          const idx = entry.target.dataset.paragraph;
          const seen = metricsRef.current.firstVisibleParagraphs;
          if (!Object.prototype.hasOwnProperty.call(seen,idx)) seen[idx] = Math.round(performance.now()-startedPerfRef.current);
        }
      }), {root:scrollRef.current,threshold:[0.15]});
      paragraphRefs.current.forEach(p=>p&&observer.observe(p));
    }
    return () => { clearInterval(interval);document.removeEventListener('visibilitychange', visibilityChanged);observer?.disconnect(); };
  }, [article.id]);
  function toggleHighlight(key, text, paragraphIndex, sentenceIndex) {
    const found = highlights.some(item=>item.key===key);
    if (!found && highlights.length>=2) {setHighlightNotice('Two sentences are already selected. Tap one to remove it before choosing another.');return;}
    const next = found ? highlights.filter(item=>item.key!==key) : [...highlights, {key, text, paragraphIndex, sentenceIndex}];
    setHighlightNotice('');
    onHighlightChange(article.id, next, { action:found?'remove':'add',key,text,paragraphIndex,sentenceIndex });
  }
  function finish(complete) {
    if (finalizedRef.current) return;
    if (complete && !canFinish) return;
    tickTime();
    recordScroll(true);
    finalizedRef.current = true;
    const m = metricsRef.current;
    onFinalize({
      articleId: article.id, title: article.title, condition: article.condition,
      startedAt: startedRef.current, endedAt:new Date().toISOString(),
      elapsedMs:Math.round(performance.now()-startedPerfRef.current),
      visibleMs:Math.round(m.visibleMs),
      maxScrollPercent:Math.round(m.maxScrollPercent*10)/10,
      scrollEventCount:m.scrollEventCount,
      scrollSamples:m.scrollSamples,
      paragraphFirstVisibleMs:m.firstVisibleParagraphs,
      visibilityTransitions:m.visibilityTransitions,
      highlights:highlights.map(item=>({...item})),
      quiz:quizAnswer ? {...quizAnswer} : null,
      configuration:{...config},
      status:complete?'completed':'closed_early'
    }, complete);
  }
  return <div className="reader" role="region" aria-label="Full news article">
    <div className="inapp-header">
      <button className="icon-plain" aria-label="Close article without completing" onClick={()=>finish(false)}><Icon name="close" size={25}/></button>
      <div className="inapp-location"><div className="inapp-title">CSS Media</div><div className="inapp-url"><Icon name="globe" size={11}/> cssmedia.example</div></div>
      <button className="icon-plain" title="Article information" onClick={()=>onArticleEvent('reader_more_tap',article.id)}><Icon name="more" size={23}/></button>
    </div>
    <div className="reader-scroll" ref={scrollRef} onScroll={handleScroll}>
      <div className="reader-site-bar"><div className="site-wordmark">CSS <span>Media</span></div><span className="reader-site-section">WORLD &amp; POLICY</span></div>
      <div className="reader-article">
        <div className="reader-kicker">LATEST NEWS <span>·</span> {ARTICLE_TOPIC_LABEL.toUpperCase()}</div>
        <h1>{article.title}</h1>
        <div className="reader-byline">By CSS Media Newsroom <span>·</span> Today</div>
        <div className="reader-divider"/>
        <ImageSlot article={article} className="reader-image" />
        <div className="reader-image-caption">Illustration placeholder. Photo to be selected.</div>
        {config.highlightEnabled && <div className="highlight-instruction"><div className="highlight-instruction-title"><Icon name="bookmark" size={17}/> While reading</div><p>Please highlight <strong>two sentences</strong> that you consider most important in this article. Tap a sentence to highlight it; tap again to remove the highlight.</p><div className="highlight-counter">{highlights.length} of 2 sentences highlighted</div></div>}
        <div className={`reader-body ${config.highlightEnabled?'reader-body--interactive':''}`}>
          {article.body.map((paragraph,idx)=><p key={idx} data-paragraph={idx} ref={node=>{paragraphRefs.current[idx]=node;}}>
            {config.highlightEnabled ? sentences[idx].map((sentence,sIndex)=> {
              const key=`${idx}:${sIndex}`;
              const chosen=highlights.some(item=>item.key===key);
              return <React.Fragment key={key}><span role="button" tabIndex={0} className={`highlight-sentence ${chosen?'highlight-sentence--selected':''}`} aria-pressed={chosen} aria-label={`${chosen?'Remove highlight from':'Highlight'} sentence: ${sentence}`} onClick={()=>toggleHighlight(key,sentence,idx,sIndex)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggleHighlight(key,sentence,idx,sIndex);}}}>{sentence}</span>{' '}</React.Fragment>;
            }) : paragraph}
          </p>)}
        </div>
        {config.highlightEnabled && highlightNotice && <p className="highlight-notice" role="status">{highlightNotice}</p>}
        {config.quizEnabled && <section className="quiz-panel" aria-label="Article attention check">
          <div className="quiz-eyebrow">ATTENTION CHECK</div>
          <h2>Quick question</h2>
          <p className="quiz-intro">Based on the article you just read, is the following statement true or false?</p>
          <p className="quiz-statement">{article.attentionCheck.statement}</p>
          {submitted ? <div className="quiz-confirmation" role="status"><Icon name="check" size={18}/> Answer recorded. Thank you.</div> : <>
            <div className="quiz-options" role="group" aria-label="Choose true or false">
              {[true,false].map(value=><button type="button" key={String(value)} className={`quiz-option ${selectedAnswer===value?'quiz-option--selected':''}`} aria-pressed={selectedAnswer===value} onClick={()=>setSelectedAnswer(value)}><span className="quiz-radio"/>{value?'True':'False'}</button>)}
            </div>
            <button className="quiz-submit" disabled={selectedAnswer===null} onClick={()=>onQuizSubmit(article.id,selectedAnswer,article.attentionCheck.correctAnswer)}>Submit answer</button>
          </>}
        </section>}
        <div className="read-done">
          <div className="read-done-icon"><Icon name="check" size={22}/></div>
          <h3>{read?'Article already completed':'Ready to finish?'}</h3>
          <p>Complete the enabled requirements below to return to the news feed and mark the article as read.</p>
          <div className="completion-checklist">
            {config.highlightEnabled && <div className={highlightDone?'complete':''}><Icon name={highlightDone?'check':'info'} size={16}/> Highlight two sentences <strong>{highlights.length}/2</strong></div>}
            {config.quizEnabled && <div className={quizDone?'complete':''}><Icon name={quizDone?'check':'info'} size={16}/> Submit your answer <strong>{quizDone?'Done':'Pending'}</strong></div>}
            {config.minimumTimeEnabled && <div className={timeDone?'complete':''}><Icon name={timeDone?'check':'info'} size={16}/> Time on article <strong>{visibleSeconds}/{targetSeconds}s</strong></div>}
            {!config.highlightEnabled&&!config.quizEnabled&&!config.minimumTimeEnabled && <div className="complete"><Icon name="check" size={16}/> No additional requirements</div>}
          </div>
          <button className="primary-action" disabled={!canFinish} onClick={()=>finish(true)}>Back to news feed</button>
          <p className="completion-footnote">Time counts while this page is visible. Closing with X saves an incomplete visit but does not mark the article as read.</p>
        </div>
      </div>
      <div className="reader-foot">© CSS Media</div>
    </div>
  </div>;
}

export default function FacebookPrototype() {
  const [condition,setCondition]=useState('NEUTRAL');
  const [quizAnswers,setQuizAnswers]=useState({});
  const [activeArticle,setActiveArticle]=useState(null);
  const [readIds,setReadIds]=useState([]);
  const [likedIds,setLikedIds]=useState([]);
  const [repostedIds,setRepostedIds]=useState([]);
  const [comments,setComments]=useState({});
  const [commentDraft,setCommentDraft]=useState('');
  const [sheet,setSheet]=useState(null);
  const [toast,setToast]=useState('');
  const [config,setConfig]=useState(DEFAULT_CONFIG);
  const [highlightSelections,setHighlightSelections]=useState({});
  const [storedLog,setStoredLog]=useState(loadLocalLog);
  const [sessions,setSessions]=useState(()=>storedLog.sessions);
  const [events,setEvents]=useState(()=>storedLog.events);
  const feedRef=useRef(null);
  const lastFeedScrollRef=useRef(0);
  const eventsRef=useRef(storedLog.events);
  useEffect(()=>{
    try { localStorage.setItem(STORAGE_KEY,JSON.stringify({events,sessions})); } catch { /* Browser storage may be unavailable in private/file mode. */ }
  },[events,sessions]);
  const articles=useMemo(()=>sourceArticles.filter((a)=>a.condition===condition).sort((a,b)=>a.coreId.localeCompare(b.coreId)),[condition]);
  const readCount=articles.filter((article)=>readIds.includes(article.id)).length;
  const visibleArticle=articles.find((article)=>article.id===activeArticle);
  const allRead=readCount===articles.length && articles.length===3;

  function logEvent(type,articleId=null,detail={}) {
    const entry={event:type,articleId,topic:ARTICLE_TOPIC,condition,at:new Date().toISOString(),...detail};
    eventsRef.current=[...eventsRef.current,entry];
    setEvents(eventsRef.current);
  }
  function resetDemo(nextCondition=condition) {
    setCondition(nextCondition);setActiveArticle(null);setSheet(null);
    setReadIds([]);setQuizAnswers({});setLikedIds([]);setRepostedIds([]);setComments({});setCommentDraft('');setToast('');
    setHighlightSelections({});logEvent('prototype_reset',null,{nextCondition});
    if(feedRef.current)feedRef.current.scrollTop=0;
  }
  function openArticle(article) {
    lastFeedScrollRef.current=feedRef.current?.scrollTop||0;
    setSheet(null);setActiveArticle(article.id);
  }
  function closeArticle() { setActiveArticle(null); logEvent('return_to_feed',activeArticle); }
  function onFinalizeArticle(summary,completed){
    const item={...summary,recordId:`${summary.articleId}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`};
    setSessions(previous=>[...previous,item]);
    logEvent('article_session_saved',summary.articleId,{status:summary.status,visibleMs:summary.visibleMs,maxScrollPercent:summary.maxScrollPercent,highlightCount:summary.highlights.length,quizSubmitted:!!summary.quiz});
    if(completed){setReadIds(prev=>prev.includes(summary.articleId)?prev:[...prev,summary.articleId]);logEvent('article_mark_read',summary.articleId);}
    closeArticle();
  }
  function updateHighlights(id,next,detail){setHighlightSelections(prev=>({...prev,[id]:next}));logEvent(`highlight_${detail.action}`,id,detail);}
  function updateSetting(key,value){setConfig(prev=>({...prev,[key]:value}));setReadIds([]);setQuizAnswers({});setHighlightSelections({});logEvent('configuration_changed',null,{setting:key,value});}
  function clearLogs(){if(!window.confirm('Clear all locally stored article sessions and event logs?'))return;eventsRef.current=[];setEvents([]);setSessions([]);try{localStorage.removeItem(STORAGE_KEY);}catch{}showToast('Local logs cleared');}
  useEffect(()=>{if(!activeArticle&&feedRef.current)feedRef.current.scrollTop=lastFeedScrollRef.current;},[activeArticle]);
  function showToast(message){setToast(message);window.setTimeout(()=>setToast(''),2600);}
  function openSheet(kind,article){setSheet({kind,article});setCommentDraft('');logEvent(`${kind}_open`,article?.id);}
  function toggleLike(id){setLikedIds(previous=>previous.includes(id)?previous.filter(x=>x!==id):[...previous,id]);logEvent('like_toggle',id);}
  function submitQuiz(id, answer, correctAnswer){if(quizAnswers[id])return;setQuizAnswers(previous=>({...previous,[id]:{answer,correct:answer===correctAnswer}}));logEvent('attention_check_submit',id,{answer,correct:answer===correctAnswer});}
  function addComment(){if(!commentDraft.trim()||!sheet?.article)return;const id=sheet.article.id;setComments(prev=>({...prev,[id]:[...(prev[id]||[]),commentDraft.trim()]}));setCommentDraft('');logEvent('comment_add',id);}
  function toggleRepost(id){setRepostedIds(previous=>previous.includes(id)?previous.filter(x=>x!==id):[...previous,id]);logEvent('share_toggle',id);setSheet(null);showToast(repostedIds.includes(id)?'Share removed (this demo only)':'Shared privately in this demo');}
  function copyLink(id){const link=`${window.location.origin}${window.location.pathname}#article=${encodeURIComponent(id)}`;if(navigator.clipboard?.writeText){navigator.clipboard.writeText(link).then(()=>showToast('Demo article link copied')).catch(()=>showToast('Could not copy link'));} else showToast('Clipboard unavailable in this browser');logEvent('copy_link',id);setSheet(null);}
  function downloadEvents(){const payload={prototype:'CSS Media Facebook-style UI v3',exportedAt:new Date().toISOString(),note:'Local demonstration only. No data has been sent to a server.',condition,configuration:config,articleSessions:sessions,events:eventsRef.current};const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='css-media-demo-events.json';a.click();URL.revokeObjectURL(url);}

  return <div className="prototype-page">
    <div className="prototype-layout">
      <div className="mobile-stage">
        <div className="fb-phone">
          <div className="fb-topbar"><div className="facebook-wordmark">facebook</div><div className="fb-head-actions"><button onClick={()=>openSheet('search',null)} aria-label="Search feed"><Icon name="search" size={20}/></button><button onClick={()=>openSheet('notifications',null)} aria-label="Notifications"><Icon name="bell" size={20}/></button><button onClick={()=>openSheet('settings',null)} aria-label="Experimental condition settings"><Icon name="menu" size={20}/></button></div></div>
          <div className="fb-tabs"><button className="active" aria-label="Home feed" onClick={()=>{if(activeArticle)closeArticle();else if(feedRef.current)feedRef.current.scrollTop=0;}}><Icon name="home" size={24} filled/></button><button aria-label="Video section" onClick={()=>openSheet('navigation',null)}><Icon name="video" size={24}/></button><button aria-label="Communities" onClick={()=>openSheet('navigation',null)}><Icon name="users" size={24}/></button></div>
          <div className="task-strip"><div className="task-strip-top"><span>NEWS READING</span><span>{readCount} of 3 read</span></div><div className="task-progress"><div style={{width:`${readCount/3*100}%`}}/></div><p>Open each article and complete the enabled reading tasks.</p></div>
          <main className="feed-scroll" ref={feedRef} aria-label="News feed" onScroll={(e)=>{lastFeedScrollRef.current=e.currentTarget.scrollTop;}}>
            <div className="feed-background">
              {articles.map((article,i)=><Post key={article.id} article={article} index={i} read={readIds.includes(article.id)} liked={likedIds.includes(article.id)} reposted={repostedIds.includes(article.id)} commentCount={(comments[article.id]||[]).length} onOpen={openArticle} onLike={toggleLike} onComment={id=>openSheet('comments',articles.find(a=>a.id===id))} onShare={openSheet}/>)}
              <div className={`end-card ${allRead?'end-card--complete':''}`}><div className="end-card-icon"><Icon name={allRead?'check':'bookmark'} size={24}/></div><strong>{allRead?'All three articles read':'End of assigned articles'}</strong><p>{allRead?'The reading task is complete. In the full experiment, the post-exposure questionnaire would appear next.':'Open each article, complete the reading requirements, then return to the feed.'}</p>{allRead&&<button className="primary-action" onClick={()=>showToast('End of prototype. Surveys are intentionally excluded.')}>Continue <Icon name="chevron" size={16}/></button>}</div>
            </div>
          </main>
          {visibleArticle&&<ArticleReader key={visibleArticle.id} article={visibleArticle} config={config} selectedHighlights={highlightSelections[visibleArticle.id] || []} onHighlightChange={updateHighlights} read={readIds.includes(visibleArticle.id)} onFinalize={onFinalizeArticle} onArticleEvent={logEvent} quizAnswer={quizAnswers[visibleArticle.id]} onQuizSubmit={submitQuiz}/>}
          {sheet&&<BottomSheet title={sheet.kind==='comments'?'Comments':sheet.kind==='share'?'Share this article':sheet.kind==='search'?'Search':sheet.kind==='notifications'?'Notifications':sheet.kind==='navigation'?'Section unavailable':sheet.kind==='settings'?'Prototype settings':'Post information'} onClose={()=>setSheet(null)}>
            {sheet.kind==='comments'&&<div className="comments-content"><div className="comments-list">{(comments[sheet.article.id]||[]).length===0?<div className="empty-state"><Icon name="comment" size={30}/><strong>No comments yet</strong><span>Be the first to comment. Comments are stored only in this demo session.</span></div>:(comments[sheet.article.id]||[]).map((c,i)=><div className="single-comment" key={i}><div className="comment-avatar">You</div><div><strong>Demo participant</strong><p>{c}</p></div></div>)}</div><form onSubmit={e=>{e.preventDefault();addComment();}} className="comment-composer"><input aria-label="Write a comment" placeholder="Write a comment..." value={commentDraft} onChange={e=>setCommentDraft(e.target.value)} maxLength={500}/><button disabled={!commentDraft.trim()} type="submit">Post</button></form></div>}
            {sheet.kind==='share'&&<div className="share-options"><button onClick={()=>toggleRepost(sheet.article.id)}><Icon name="share"/><span>{repostedIds.includes(sheet.article.id)?'Undo share':'Share to your feed (demo only)'}</span></button><button onClick={()=>copyLink(sheet.article.id)}><Icon name="link"/><span>Copy demo article link</span></button><p>No post will be published to a real social network.</p></div>}
            {sheet.kind==='settings'&&<div className="settings-content">
              <div className="settings-note"><Icon name="info" size={18}/><span>Research prototype settings. These controls are for reviewing the UI, not for study participants.</span></div>
              <label className="settings-label" htmlFor="condition-select">Experimental condition</label>
              <select id="condition-select" value={condition} onChange={e=>resetDemo(e.target.value)}>{CONDITIONS.map(c=><option key={c.value} value={c.value}>{c.label}</option>)}</select>
              <p className="settings-detail">The feed always contains three immigration articles. Changing conditions resets reading progress and reactions.</p>
              <div className="settings-section-title">Reading requirements</div>
              <label className="settings-switch-row"><span><strong>Sentence highlighting</strong><small>Require two highlighted sentences per article</small></span><input type="checkbox" checked={config.highlightEnabled} onChange={e=>updateSetting('highlightEnabled',e.target.checked)}/></label>
              <label className="settings-switch-row"><span><strong>Attention check quiz</strong><small>Require an answer before completion</small></span><input type="checkbox" checked={config.quizEnabled} onChange={e=>updateSetting('quizEnabled',e.target.checked)}/></label>
              <label className="settings-switch-row"><span><strong>Minimum article time</strong><small>Count time only when the article is visible</small></span><input type="checkbox" checked={config.minimumTimeEnabled} onChange={e=>updateSetting('minimumTimeEnabled',e.target.checked)}/></label>
              <label className="settings-label settings-number-label" htmlFor="minimum-seconds">Minimum visible time (seconds)</label>
              <input id="minimum-seconds" className="settings-number" type="number" min="0" max="600" step="1" value={config.minimumSeconds} disabled={!config.minimumTimeEnabled} onChange={e=>updateSetting('minimumSeconds',Math.max(0,Math.min(600,Math.floor(Number(e.target.value)||0))))}/>
              <p className="settings-detail">Changing a requirement clears reading progress, highlights, and quiz answers. Previously saved interaction logs remain available for export.</p>
              <div className="settings-progress"><span>Reading progress</span><strong>{readCount} / 3</strong></div>
              <button className="settings-action" onClick={()=>resetDemo()}><Icon name="refresh" size={17}/> Reset demonstration</button>
              <div className="settings-progress"><span>Saved article visits</span><strong>{sessions.length}</strong></div>
              <button className="settings-action" onClick={downloadEvents}><Icon name="external" size={17}/> Export article sessions + event log (JSON)</button>
              <button className="settings-action settings-action--danger" onClick={clearLogs}>Clear saved logs</button>
              <p className="settings-footnote">Article text and true/false attention checks are taken from the uploaded Step 2 source data. Preview excerpts and post captions remain placeholders.</p>
            </div>}
            {sheet.kind==='search'&&<div className="sheet-simple"><Icon name="search"/><p>Search is not part of this three-article demonstration.</p></div>}
            {sheet.kind==='notifications'&&<div className="sheet-simple"><Icon name="bell"/><p>No notifications.</p></div>}
            {sheet.kind==='navigation'&&<div className="sheet-simple"><Icon name="info"/><p>This prototype contains the news feed only.</p></div>}
            {(sheet.kind==='about'||sheet.kind==='info')&&<div className="sheet-simple"><Icon name="info"/><p>CSS Media is a fictional publisher used for a research UI demonstration. The article, reactions, and sharing controls work locally; no data is uploaded.</p></div>}
          </BottomSheet>}
          {toast&&<div className="toast" role="status">{toast}</div>}
        </div>
      </div>
    </div>
  </div>;
}
