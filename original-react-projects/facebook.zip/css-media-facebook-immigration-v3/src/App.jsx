import React from 'react';
import FacebookPrototype from './prototype/FacebookPrototype';
import './prototype/facebook-prototype.css';

export default function App() {
  return <FacebookPrototype />;
}
