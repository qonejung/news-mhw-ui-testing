export const saveToGoogleSheet = async (finalData) => {
  const url = "https://script.google.com/macros/s/AKfycbyVb14rDyoAFLnxH7PPbW9_CZWgeFL3Ja8gHdX8aO3Z7siuFx2EbAIvnx0CGiB3xpmE/exec";
  
  try {
    const response = await fetch(url, {
      method: "POST",
      mode: "no-cors",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(finalData)
    });
    console.log("Data successfully logged to Google Sheets");
    return true;
  } catch (error) {
    console.error("Failed to log data:", error);
    return false;
  }
};