// src/components/step4.jsx
import React, { useState } from 'react';
import { TEST_MODE } from '../config/experimentConfig';

const TOPICS = {
  IMMIGRATION: {
    label: 'Immigration policy',
    stanceQuestion:
      '10. Which of the following positions comes closer to your view on immigration policy?',
    stanceLabels: {
      1: 'Strongly favor allowing more immigration',
      4: 'Neither / about in the middle',
      7: 'Strongly favor restricting immigration',
    },
    importanceQuestion:
      '11. How personally important is the issue of immigration policy to you?',
  },
  CLIMATE: {
    label: 'Climate change action',
    stanceQuestion:
      '10. Which of the following positions comes closer to your view on government regulations aimed at addressing climate change?',
    stanceLabels: {
      1: 'Strongly favor stronger regulations',
      4: 'Neither / about in the middle',
      7: 'Strongly favor less stringent regulations',
    },
    importanceQuestion:
      '11. How personally important is the issue of climate change action to you?',
  },
  GENDER_LGBTQ: {
    label: 'Gender equality and LGBTQ+ rights',
    stanceQuestion:
      '10. Which of the following positions comes closer to your view on legal protections and institutional support for gender minorities and LGBTQ+ rights?',
    stanceLabels: {
      1: 'Strongly favor expanding protections and support',
      4: 'Neither / about in the middle',
      7: 'Strongly favor reducing protections and support',
    },
    importanceQuestion:
      '11. How personally important is the issue of gender equality and LGBTQ+ rights to you?',
  },
};

const initialFormData = {
  ageGroup: '',
  gender: '',
  genderSelfDescribe: '',
  education: '',
  employment: '',
  householdIncome: '',
  newsDays: '',
  newsTime: '',
  politicalOrientation: '',
  politicalParty: '',
  issueStance: '',
  issueImportance: '',
};

const SectionHeading = ({ children }) => (
  <h2 className="text-lg font-bold text-blue-800 border-b pb-2 border-gray-200 uppercase tracking-wide">
    {children}
  </h2>
);

const QuestionBox = ({ label, children, description }) => (
  <div className="space-y-3 text-left">
    <div>
      <label className="block text-base font-bold text-gray-900 leading-snug whitespace-pre-line">
        {label}
      </label>
      {description && (
        <p className="mt-1 text-sm leading-relaxed text-gray-500">{description}</p>
      )}
    </div>
    <div className="w-full">{children}</div>
  </div>
);

const RadioList = ({ name, value, options, onChange }) => (
  <div className="flex flex-col space-y-3 text-base">
    {options.map((option) => {
      const optionValue = typeof option === 'string' ? option : option.value;
      const optionLabel = typeof option === 'string' ? option : option.label;

      return (
        <label key={optionValue} className="flex items-start gap-3 cursor-pointer py-0.5">
          <input
            type="radio"
            name={name}
            value={optionValue}
            checked={value === optionValue}
            onChange={() => onChange(optionValue)}
            className="w-5 h-5 mt-0.5 text-blue-600 focus:ring-blue-500 flex-shrink-0"
          />
          <span className="text-gray-700 font-medium leading-tight">{optionLabel}</span>
        </label>
      );
    })}
  </div>
);

const LikertScale = ({ name, value, min = 1, max = 7, labels = {}, onChange }) => {
  const values = Array.from({ length: max - min + 1 }, (_, index) => min + index);
  const gridStyle = { gridTemplateColumns: `repeat(${values.length}, minmax(0, 1fr))` };

  return (
    <div className="bg-gray-50 p-3 sm:p-4 rounded-xl border border-gray-200 w-full">
      <div className="grid gap-0.5 sm:gap-2 text-center items-start px-2 sm:px-6" style={gridStyle}>
        {values.map((number) => (
          <label key={number} className="min-w-0 flex flex-col items-center gap-2 cursor-pointer">
            <span className="text-sm font-semibold text-gray-600">{number}</span>
            <input
              type="radio"
              name={name}
              value={number}
              checked={value === String(number)}
              onChange={() => onChange(String(number))}
              className="w-5 h-5 text-blue-600 cursor-pointer shrink-0"
              aria-label={`${name}: ${number}${labels[number] ? `, ${labels[number]}` : ''}`}
            />
          </label>
        ))}
      </div>
      <div
        className="grid gap-0.5 sm:gap-2 mt-4 px-2 sm:px-6 text-xs sm:text-sm text-gray-600 leading-snug"
        style={gridStyle}
      >
        {values.map((number) => (
          <div key={`label-${number}`} className="min-w-0 flex justify-center text-center">
            {labels[number] ? (
              <span className="w-full max-w-[14rem] break-words">{labels[number]}</span>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  );
};

const toNullableNumber = (value) => (
  value === '' || value === null || value === undefined ? null : Number(value)
);

const Step4 = ({ selectedTopic, onComplete }) => {
  const [formData, setFormData] = useState(initialFormData);
  const [validationMessage, setValidationMessage] = useState('');
  const topic = TOPICS[selectedTopic];

  const updateField = (name, value) => {
    setFormData((previous) => ({ ...previous, [name]: value }));
    setValidationMessage('');
  };

  const validate = () => {
    if (TEST_MODE) return '';

    const requiredFields = [
      'ageGroup',
      'gender',
      'education',
      'employment',
      'householdIncome',
      'newsDays',
      'newsTime',
      'politicalOrientation',
      'politicalParty',
      'issueStance',
      'issueImportance',
    ];

    if (requiredFields.some((field) => !formData[field])) {
      return 'Please answer all questions before completing the study.';
    }

    if (formData.gender === 'SELF_DESCRIBE' && !formData.genderSelfDescribe.trim()) {
      return 'Please enter your self-described gender before completing the study.';
    }

    return '';
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const message = validate();

    if (message) {
      setValidationMessage(message);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    onComplete({
      demographics: {
        ageGroup: formData.ageGroup,
        gender: formData.gender,
        genderSelfDescribe:
          formData.gender === 'SELF_DESCRIBE' ? formData.genderSelfDescribe.trim() : '',
        education: formData.education,
        employment: formData.employment,
        householdIncome: formData.householdIncome,
      },
      newsConsumption: {
        newsDays: formData.newsDays,
        newsTime: formData.newsTime,
      },
      politics: {
        politicalOrientation: toNullableNumber(formData.politicalOrientation),
        politicalParty: formData.politicalParty,
      },
      issue: {
        selectedTopic,
        stance: toNullableNumber(formData.issueStance),
        importance: toNullableNumber(formData.issueImportance),
      },
      completedAt: new Date().toISOString(),
    });
  };

  if (!topic) {
    return (
      <div className="bg-white rounded-xl shadow-md border border-red-200 p-8 md:p-10 text-left w-full mx-auto my-6">
        <h1 className="text-2xl font-bold text-red-800 mb-3">Step 4 configuration error</h1>
        <p className="text-base text-red-700">A topic selection from Step 2 is required.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
      <div className="mb-7 border-b pb-6 border-gray-100">
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 4</p>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">Background Information</h1>
        <p className="text-base text-gray-600 leading-relaxed">
          Please answer the following questions about yourself and your views.
        </p>
      </div>

      {validationMessage && (
        <div
          role="alert"
          className="mb-7 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
        >
          {validationMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-10">
        <section className="space-y-8">
          <SectionHeading>Demographics &amp; Socioeconomic Status</SectionHeading>

          <QuestionBox label="1. What is your age group?">
            <RadioList name="ageGroup" value={formData.ageGroup} onChange={(value) => updateField('ageGroup', value)} options={['18–29', '30–39', '40–49', '50–59', '60–64']} />
          </QuestionBox>

          <QuestionBox label="2. What is your gender?">
            <div className="flex flex-col space-y-3 text-base">
              <RadioList
                name="gender"
                value={formData.gender}
                onChange={(value) => updateField('gender', value)}
                options={[
                  { value: 'FEMALE', label: 'Female' },
                  { value: 'MALE', label: 'Male' },
                  { value: 'SELF_DESCRIBE', label: 'Prefer to self-describe' },
                  { value: 'PREFER_NOT_TO_SAY', label: 'Prefer not to say' },
                ]}
              />
              {formData.gender === 'SELF_DESCRIBE' && (
                <input
                  type="text"
                  value={formData.genderSelfDescribe}
                  onChange={(event) => updateField('genderSelfDescribe', event.target.value)}
                  placeholder="Please self-describe"
                  className="ml-7 w-full max-w-sm rounded-md border border-gray-300 bg-gray-50 p-2.5 text-base focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              )}
            </div>
          </QuestionBox>

          <QuestionBox label="3. What is the highest level of education you have completed?">
            <RadioList
              name="education"
              value={formData.education}
              onChange={(value) => updateField('education', value)}
              options={[
                'Less than high school',
                'High school diploma or GED',
                'Some college, no degree',
                'Associate degree',
                "Bachelor's degree",
                "Graduate or professional degree (Master's, Doctorate, JD, MD, etc.)",
                'Prefer not to say',
              ]}
            />
          </QuestionBox>

          <QuestionBox label="4. What is your current employment status?">
            <RadioList
              name="employment"
              value={formData.employment}
              onChange={(value) => updateField('employment', value)}
              options={[
                'Employed (Full-time / Part-time)',
                'Self-employed',
                'Student',
                'Unemployed / Looking for work',
                'Retired / Other',
                'Prefer not to say',
              ]}
            />
          </QuestionBox>

          <QuestionBox label="5. What is your approximate annual household income (before taxes)?">
            <RadioList
              name="householdIncome"
              value={formData.householdIncome}
              onChange={(value) => updateField('householdIncome', value)}
              options={[
                'Under $30,000',
                '$30,000 – $59,999',
                '$60,000 – $89,999',
                '$90,000 – $119,999',
                '$120,000 or above',
                'Prefer not to say',
              ]}
            />
          </QuestionBox>
        </section>

        <section className="space-y-8">
          <SectionHeading>Media &amp; News Consumption</SectionHeading>
          <QuestionBox label="6. In the past 7 days, on how many days did you consume news about politics or society?">
            <RadioList
              name="newsDays"
              value={formData.newsDays}
              onChange={(value) => updateField('newsDays', value)}
              options={['0 days (Never)', '1–2 days', '3–4 days', '5–6 days', 'Every day (7 days)']}
            />
          </QuestionBox>
          <QuestionBox label="7. On a typical day, how much time do you spend consuming news? (Including digital news, social media, TV, and print)">
            <RadioList
              name="newsTime"
              value={formData.newsTime}
              onChange={(value) => updateField('newsTime', value)}
              options={['I do not consume news daily', 'Less than 30 minutes', '30 minutes – 1 hour', '1–2 hours', 'More than 2 hours']}
            />
          </QuestionBox>
        </section>

        <section className="space-y-8">
          <SectionHeading>Political Orientation &amp; Leanings</SectionHeading>
          <QuestionBox label={'8. In political matters, people talk about "liberal" and "conservative." How would you place your views on this scale?'}>
            <LikertScale
              name="politicalOrientation"
              value={formData.politicalOrientation}
              min={1}
              max={7}
              labels={{ 1: 'Very Liberal', 4: 'Moderate', 7: 'Very Conservative' }}
              onChange={(value) => updateField('politicalOrientation', value)}
            />
          </QuestionBox>
          <QuestionBox label="9. Which political party do you currently feel closest to?">
            <RadioList
              name="politicalParty"
              value={formData.politicalParty}
              onChange={(value) => updateField('politicalParty', value)}
              options={['Democratic Party', 'Republican Party', 'Independent / No party', 'Other party', 'Prefer not to say']}
            />
          </QuestionBox>
        </section>

        <section className="space-y-8">
          <SectionHeading>{topic.label}</SectionHeading>
          <QuestionBox label={topic.stanceQuestion}>
            <LikertScale
              name="issueStance"
              value={formData.issueStance}
              min={1}
              max={7}
              labels={topic.stanceLabels}
              onChange={(value) => updateField('issueStance', value)}
            />
          </QuestionBox>
          <QuestionBox label={topic.importanceQuestion}>
            <LikertScale
              name="issueImportance"
              value={formData.issueImportance}
              min={1}
              max={7}
              labels={{ 1: 'Not important at all', 4: 'Moderately important', 7: 'Extremely important' }}
              onChange={(value) => updateField('issueImportance', value)}
            />
          </QuestionBox>
        </section>

        <div className="pt-4 border-t border-gray-200 flex justify-end">
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
          >
            Complete Step 4
          </button>
        </div>
      </form>
    </div>
  );
};

export default Step4;
