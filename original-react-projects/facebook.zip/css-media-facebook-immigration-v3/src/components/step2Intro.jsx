// src/components/step2Intro.jsx
import React from 'react';

const AssignedIntro = ({ onStart }) => {
  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-8 md:p-10 text-left w-full font-sans animate-fadeIn">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Step 2: News Article Reading</h2>
      
      <div className="space-y-4 text-sm text-gray-600 leading-relaxed">
        <p>
          In this section, you will be presented with <strong>three separate short news articles</strong> covering recent public developments and general socio-environmental updates in Finland.
        </p>
        <p>
          Please read each article carefully at your regular pacing. Once you reach the bottom of an article, a brief evaluation matrix will appear immediately below the text for you to log your reactions.
        </p>
        <p className="bg-blue-50 border border-blue-200 text-blue-900 rounded-lg p-3 font-medium">
          💡 Note: The next button and evaluation panel will remain hidden until you have scrolled through the entire content of each article text box.
        </p>
      </div>

      <div className="pt-6 mt-6 border-t border-gray-100">
        <button
          onClick={onStart}
          className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-sm tracking-wide"
        >
          Start News Reading Session
        </button>
      </div>
    </div>
  );
};

export default AssignedIntro;