// src/components/step3.jsx
import React, { useState } from 'react';
import allArticles from '../data/step3Articles.json';
import { STEP3_PREVIEW_WORD_LIMIT, TEST_MODE } from '../config/experimentConfig';

const TOPIC_LABELS = {
  IMMIGRATION: 'Immigration policy',
  CLIMATE: 'Climate change action',
  GENDER_LGBTQ: 'Gender equality and LGBTQ+ rights',
};

const randomIndex = (length) => {
  if (length <= 1) return 0;

  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const randomRange = 0x100000000;
    const limit = randomRange - (randomRange % length);
    const buffer = new Uint32Array(1);

    do {
      crypto.getRandomValues(buffer);
    } while (buffer[0] >= limit);

    return buffer[0] % length;
  }

  return Math.floor(Math.random() * length);
};

const shuffleArray = (items) => {
  const copy = [...items];

  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = randomIndex(index + 1);
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }

  return copy;
};

const makePreview = (article, wordLimit) => {
  const words = article.body.join(' ').trim().split(/\s+/).filter(Boolean);
  const clipped = words.slice(0, wordLimit).join(' ');
  return words.length > wordLimit ? `${clipped}…` : clipped;
};

const getTopicSets = (topic) => {
  const grouped = allArticles
    .filter((article) => article.topic === topic)
    .reduce((accumulator, article) => {
      if (!accumulator[article.coreId]) accumulator[article.coreId] = [];
      accumulator[article.coreId].push(article);
      return accumulator;
    }, {});

  return Object.entries(grouped)
    .filter(([, articles]) => articles.length === 3)
    .map(([coreId, articles]) => ({ coreId, topic, articles }));
};

const buildChoiceSets = (selectedTopic) => {
  const unselectedTopics = Object.keys(TOPIC_LABELS).filter((topic) => topic !== selectedTopic);
  const comparisonTopic = unselectedTopics[randomIndex(unselectedTopics.length)];

  const selectedTopicSets = getTopicSets(selectedTopic);
  const comparisonTopicSets = getTopicSets(comparisonTopic);

  if (selectedTopicSets.length === 0 || comparisonTopicSets.length === 0) {
    return { comparisonTopic, sets: [] };
  }

  const selectedSet = selectedTopicSets[randomIndex(selectedTopicSets.length)];
  const comparisonSet = comparisonTopicSets[randomIndex(comparisonTopicSets.length)];

  const sets = shuffleArray([
    {
      ...selectedSet,
      sourceRole: 'SELECTED_TOPIC',
      articles: shuffleArray(selectedSet.articles),
    },
    {
      ...comparisonSet,
      sourceRole: 'UNSELECTED_TOPIC',
      articles: shuffleArray(comparisonSet.articles),
    },
  ]);

  return { comparisonTopic, sets };
};

const Step3 = ({ selectedTopic, assignedCondition, onComplete }) => {
  const [assignment] = useState(() => buildChoiceSets(selectedTopic));
  const choiceSets = assignment.sets;
  const [setIndex, setSetIndex] = useState(0);
  const [selectedArticleId, setSelectedArticleId] = useState('');
  const [reason, setReason] = useState('');
  const [choices, setChoices] = useState([]);
  const [validationMessage, setValidationMessage] = useState('');
  const [choiceStartedAt, setChoiceStartedAt] = useState(() => Date.now());

  const currentSet = choiceSets[setIndex];

  if (
    choiceSets.length !== 2
    || choiceSets.some((set) => set.articles.length !== 3)
  ) {
    return (
      <div className="bg-white rounded-xl shadow-md border border-red-200 p-8 md:p-10 text-left w-full mx-auto my-6">
        <h1 className="text-2xl font-bold text-red-800 mb-3">Step 3 configuration error</h1>
        <p className="text-base text-red-700 leading-relaxed">
          Expected two article-choice sets with three previews in each set.
        </p>
      </div>
    );
  }

  const chooseArticle = (articleId) => {
    setSelectedArticleId(articleId);
    setValidationMessage('');
  };

  const submitChoice = () => {
    if (!TEST_MODE && !selectedArticleId) {
      setValidationMessage('Please choose the article you would most like to read.');
      return;
    }

    const submittedAt = Date.now();
    const selectedArticle = currentSet.articles.find(
      (article) => article.id === selectedArticleId,
    );

    const response = {
      taskPosition: setIndex + 1,
      topic: currentSet.topic,
      topicLabel: TOPIC_LABELS[currentSet.topic],
      sourceRole: currentSet.sourceRole,
      coreId: currentSet.coreId,
      displayOrder: currentSet.articles.map((article) => article.id),
      selectedArticleId: selectedArticle?.id || null,
      selectedCondition: selectedArticle?.condition || null,
      reason: reason.trim() || null,
      startedAt: new Date(choiceStartedAt).toISOString(),
      submittedAt: new Date(submittedAt).toISOString(),
      decisionTimeSeconds: Math.max(0, Math.round((submittedAt - choiceStartedAt) / 1000)),
    };

    const updatedChoices = [...choices, response];
    setChoices(updatedChoices);

    if (setIndex < choiceSets.length - 1) {
      setSetIndex((previous) => previous + 1);
      setSelectedArticleId('');
      setReason('');
      setValidationMessage('');
      setChoiceStartedAt(Date.now());
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    onComplete({
      selectedTopic,
      comparisonTopic: assignment.comparisonTopic,
      assignedCondition,
      topicOrder: choiceSets.map((set) => set.topic),
      setOrder: choiceSets.map((set) => set.coreId),
      choices: updatedChoices,
      completedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
      <div className="mb-7 border-b border-gray-100 pb-6">
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 3</p>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">Choosing What to Read</h1>
        <p className="text-base text-gray-600 leading-relaxed">
          Below are previews of three news articles about <strong>{TOPIC_LABELS[currentSet.topic]}</strong>.
        </p>
      </div>

      <div className="mb-7">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
          <p className="text-base font-semibold text-gray-800">
            Choice {setIndex + 1} of {choiceSets.length}
          </p>
          <p className="text-sm text-gray-500">Choose one article</p>
        </div>
        <div className="grid grid-cols-2 gap-2" aria-hidden="true">
          {choiceSets.map((set, index) => (
            <div
              key={`${set.topic}-${set.coreId}`}
              className={`h-1.5 rounded-full ${index <= setIndex ? 'bg-blue-600' : 'bg-gray-200'}`}
            />
          ))}
        </div>
      </div>

      <section className="space-y-5">
        <div>
          <h2 className="text-xl font-bold text-gray-900">Which article would you most like to read?</h2>
          <p className="mt-1 text-base text-gray-600 leading-relaxed">
            Select the preview that interests you most.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5 items-stretch">
          {currentSet.articles.map((article, index) => {
            const isSelected = selectedArticleId === article.id;
            const displayLabel = `Article ${String.fromCharCode(65 + index)}`;

            return (
              <button
                key={article.id}
                type="button"
                onClick={() => chooseArticle(article.id)}
                aria-pressed={isSelected}
                className={`h-full text-left rounded-xl border-2 p-5 transition duration-150 cursor-pointer flex flex-col focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                  isSelected
                    ? 'border-blue-600 bg-blue-50 shadow-md'
                    : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-sm'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-4">
                  <span className="text-sm font-semibold uppercase tracking-wide text-blue-600">
                    {displayLabel}
                  </span>
                  <span
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${
                      isSelected ? 'border-blue-600' : 'border-gray-300'
                    }`}
                    aria-hidden="true"
                  >
                    {isSelected && <span className="w-2.5 h-2.5 rounded-full bg-blue-600" />}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-950 leading-snug mb-4">
                  {article.title}
                </h3>

                <p className="text-base text-gray-700 leading-7 flex-1">
                  {makePreview(article, STEP3_PREVIEW_WORD_LIMIT)}
                </p>

                <div className="mt-5 pt-4 border-t border-gray-200">
                  <span className={`text-base font-semibold ${isSelected ? 'text-blue-700' : 'text-gray-600'}`}>
                    {isSelected ? 'Selected' : 'Select this article'}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        <div className="pt-3">
          <label htmlFor={`choice-reason-${currentSet.coreId}`} className="block text-base font-bold text-gray-900 mb-2">
            Why did you choose this article? <span className="font-normal text-gray-500">(Optional)</span>
          </label>
          <textarea
            id={`choice-reason-${currentSet.coreId}`}
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            rows={3}
            placeholder="Briefly tell us what influenced your choice."
            className="w-full rounded-lg border border-gray-300 bg-white px-4 py-3 text-base text-gray-800 placeholder:text-gray-400 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-200 resize-y"
          />
        </div>

        {validationMessage && (
          <div
            role="alert"
            className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
          >
            {validationMessage}
          </div>
        )}

        <div className="pt-4 border-t border-gray-200 flex justify-end">
          <button
            type="button"
            onClick={submitChoice}
            className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
          >
            {setIndex < choiceSets.length - 1 ? 'Next Choice' : 'Complete Step 3'}
          </button>
        </div>
      </section>
    </div>
  );
};

export default Step3;
