// src/components/step1.jsx
import React, { useState } from 'react';
import { TEST_MODE } from '../config/experimentConfig';

// The survey source lists the STAI-6 items but does not state the response labels.
// These 1-4 labels remain a development default and should be verified before deployment.
const STAI_RESPONSE_LABELS = {
  1: 'Not at all',
  2: 'Somewhat',
  3: 'Moderately so',
  4: 'Very much so',
};

const STAI_ITEMS = [
  ['calm', 'I feel calm'],
  ['tense', 'I am tense'],
  ['upset', 'I feel upset'],
  ['relaxed', 'I am relaxed'],
  ['content', 'I feel content'],
  ['worried', 'I am worried'],
];

const PANAS_ITEMS = [
  ['upset', 'Upset'],
  ['hostile', 'Hostile'],
  ['alert', 'Alert'],
  ['ashamed', 'Ashamed'],
  ['inspired', 'Inspired'],
  ['nervous', 'Nervous'],
  ['determined', 'Determined'],
  ['attentive', 'Attentive'],
  ['afraid', 'Afraid'],
  ['active', 'Active'],
];

const initialFormData = {
  sam: {
    valence: '',
    arousal: '',
    dominance: '',
  },
  stai: {
    calm: '',
    tense: '',
    upset: '',
    relaxed: '',
    content: '',
    worried: '',
  },
  stress: '',
  panas: {
    upset: '',
    hostile: '',
    alert: '',
    ashamed: '',
    inspired: '',
    nervous: '',
    determined: '',
    attentive: '',
    afraid: '',
    active: '',
  },
};

const SectionHeading = ({ children }) => (
  <h2 className="text-lg font-bold text-blue-800 border-b pb-2 border-gray-200 uppercase tracking-wide">
    {children}
  </h2>
);

const QuestionBox = ({ label, children, description }) => (
  <div className="space-y-3 text-left">
    <div>
      <label className="block text-base font-bold text-gray-900 leading-snug whitespace-pre-line">
        {label}
      </label>
      {description && (
        <p className="mt-1 text-sm leading-relaxed text-gray-500">{description}</p>
      )}
    </div>
    <div className="w-full">{children}</div>
  </div>
);

const LikertScale = ({ name, value, min = 1, max = 7, labels = {}, onChange }) => {
  const values = Array.from({ length: max - min + 1 }, (_, index) => min + index);
  const labelEntries = Object.entries(labels);
  const useAnchorLabels = labelEntries.length > 0 && labelEntries.length <= 3;
  const gridStyle = { gridTemplateColumns: `repeat(${values.length}, minmax(0, 1fr))` };

  return (
    <div className="bg-gray-50 p-3 sm:p-4 rounded-xl border border-gray-200 w-full">
      <div className="grid gap-0.5 sm:gap-2 text-center items-start px-2 sm:px-6" style={gridStyle}>
        {values.map((number) => (
          <label key={number} className="min-w-0 flex flex-col items-center gap-2 cursor-pointer">
            <span className="text-sm font-semibold text-gray-600">{number}</span>
            <input
              type="radio"
              name={name}
              value={number}
              checked={value === String(number)}
              onChange={() => onChange(String(number))}
              className="w-5 h-5 text-blue-600 cursor-pointer shrink-0"
              aria-label={`${name}: ${number}${labels[number] ? `, ${labels[number]}` : ''}`}
            />
          </label>
        ))}
      </div>

      {useAnchorLabels && (
        <div
          className="grid gap-0.5 sm:gap-2 mt-4 px-2 sm:px-6 text-xs sm:text-sm text-gray-600 leading-snug"
          style={gridStyle}
        >
          {values.map((number) => (
            <div key={`label-${number}`} className="min-w-0 flex justify-center text-center">
              {labels[number] ? (
                <span className="w-full max-w-[14rem] break-words">{labels[number]}</span>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const SAM_DETAILS = {
  Valence: {
    description: 'Your emotional feeling, from unhappy/unpleasant to happy/pleasant',
    imageSrc: '/images/sam_valence.png',
    imageAlt: 'SAM valence scale from unhappy or unpleasant to happy or pleasant',
  },
  Arousal: {
    description: 'Your level of activation, from calm/sleepy to excited/wide awake',
    imageSrc: '/images/sam_arousal.png',
    imageAlt: 'SAM arousal scale from calm or sleepy to excited or wide awake',
  },
  Dominance: {
    description: 'Your sense of control, from controlled/helpless to in control/powerful',
    imageSrc: '/images/sam_dominance.png',
    imageAlt: 'SAM dominance scale from controlled or helpless to in control or powerful',
  },
};

const SamScale = ({ dimension, value, onChange }) => {
  const details = SAM_DETAILS[dimension];

  return (
    <div className="rounded-xl border border-gray-200 bg-gray-50 p-4 sm:p-5 space-y-4">
      <p className="text-base sm:text-lg font-semibold text-gray-800 leading-relaxed">
        {dimension}: <span className="font-normal text-gray-600">{details.description}</span>
      </p>
      <div className="rounded-lg border border-gray-200 bg-white p-3 sm:p-4">
        <img
          src={details.imageSrc}
          alt={details.imageAlt}
          className="block w-full max-w-[668px] h-auto mx-auto"
        />
      </div>
      <LikertScale
        name={`sam-${dimension.toLowerCase()}`}
        value={value}
        min={1}
        max={9}
        onChange={onChange}
      />
    </div>
  );
};

const toNullableNumber = (value) => (
  value === '' || value === null || value === undefined ? null : Number(value)
);

const Step1Survey = ({ onNext }) => {
  const [formData, setFormData] = useState(initialFormData);
  const [validationMessage, setValidationMessage] = useState('');

  const updateField = (name, value) => {
    setFormData((previous) => ({ ...previous, [name]: value }));
    setValidationMessage('');
  };

  const updateNestedField = (group, name, value) => {
    setFormData((previous) => ({
      ...previous,
      [group]: {
        ...previous[group],
        [name]: value,
      },
    }));
    setValidationMessage('');
  };

  const validate = () => {
    if (TEST_MODE) return '';

    if (Object.values(formData.sam).some((value) => value === '')) {
      return 'Please complete all three SAM ratings.';
    }

    if (Object.values(formData.stai).some((value) => value === '')) {
      return 'Please complete all six state-anxiety items.';
    }

    if (formData.stress === '') {
      return 'Please complete the stress rating.';
    }

    if (Object.values(formData.panas).some((value) => value === '')) {
      return 'Please complete all ten affect ratings.';
    }

    return '';
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    const message = validate();

    if (message) {
      setValidationMessage(message);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    onNext({
      preExposure: {
        sam: {
          valence: toNullableNumber(formData.sam.valence),
          arousal: toNullableNumber(formData.sam.arousal),
          dominance: toNullableNumber(formData.sam.dominance),
        },
        stai: Object.fromEntries(
          Object.entries(formData.stai).map(([key, value]) => [key, toNullableNumber(value)]),
        ),
        stress: toNullableNumber(formData.stress),
        panas: Object.fromEntries(
          Object.entries(formData.panas).map(([key, value]) => [key, toNullableNumber(value)]),
        ),
      },
      completedAt: new Date().toISOString(),
    });
  };

  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
      <div className="mb-7 border-b pb-6 border-gray-100">
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 1</p>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">Affective &amp; Psychological State</h1>
        <p className="text-base text-gray-600 leading-relaxed">
          Before continuing, please answer a few brief questions about how you are feeling right now.
        </p>
      </div>

      {validationMessage && (
        <div
          role="alert"
          className="mb-7 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
        >
          {validationMessage}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-10">
        <section className="space-y-8">
          <SectionHeading>Affective &amp; Psychological State</SectionHeading>

          <QuestionBox label="1. Please rate valence, arousal, and dominance using the 9-point scales below.">
            <div className="space-y-5">
              <SamScale
                dimension="Valence"
                value={formData.sam.valence}
                onChange={(value) => updateNestedField('sam', 'valence', value)}
              />
              <SamScale
                dimension="Arousal"
                value={formData.sam.arousal}
                onChange={(value) => updateNestedField('sam', 'arousal', value)}
              />
              <SamScale
                dimension="Dominance"
                value={formData.sam.dominance}
                onChange={(value) => updateNestedField('sam', 'dominance', value)}
              />
            </div>
          </QuestionBox>

          <QuestionBox label="2. Please indicate how you feel right now for each item.">
            <div className="space-y-4">
              {STAI_ITEMS.map(([key, label]) => (
                <div key={key} className="rounded-lg border border-gray-200 p-4">
                  <p className="mb-3 text-base font-medium text-gray-800">{label}</p>
                  <LikertScale
                    name={`stai-${key}`}
                    value={formData.stai[key]}
                    min={1}
                    max={4}
                    labels={STAI_RESPONSE_LABELS}
                    onChange={(value) => updateNestedField('stai', key, value)}
                  />
                </div>
              ))}
            </div>
          </QuestionBox>

          <QuestionBox label="3. On a scale of 0 to 10, with 0 being no stress and 10 being extreme stress, what number best describes your level of stress right now?">
            <LikertScale
              name="stress"
              value={formData.stress}
              min={0}
              max={10}
              labels={{ 0: 'No stress', 10: 'Extreme stress' }}
              onChange={(value) => updateField('stress', value)}
            />
          </QuestionBox>

          <QuestionBox label="4. Thinking about yourself and how you feel now, to what extent do you feel the following?">
            <div className="space-y-3">
              {PANAS_ITEMS.map(([key, label]) => (
                <div
                  key={key}
                  className="grid grid-cols-1 md:grid-cols-[180px_1fr] gap-3 md:items-center rounded-lg border border-gray-200 p-4"
                >
                  <p className="text-base font-semibold text-gray-800">{label}</p>
                  <LikertScale
                    name={`panas-${key}`}
                    value={formData.panas[key]}
                    min={1}
                    max={5}
                    labels={{ 1: 'Never', 5: 'Always' }}
                    onChange={(value) => updateNestedField('panas', key, value)}
                  />
                </div>
              ))}
            </div>
          </QuestionBox>
        </section>

        <div className="pt-4 border-t border-gray-200 flex justify-end">
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
          >
            Complete Step 1
          </button>
        </div>
      </form>
    </div>
  );
};

export default Step1Survey;
