// src/components/step2NewsRead.jsx
import React, { useState, useRef, useEffect } from 'react';

const SCALE_QUESTIONS = [
  { id: "affect", label: "How did reading this news article make you feel emotionally?", left: "Very Negative", mid: "Neutral", right: "Very Positive" },
  { id: "polarization", label: "How polarizing do you perceive the content of this article to be?", left: "Not polarizing at all", mid: "Moderately polarizing", right: "Extremely polarizing" }
];

const AssignedReadingLoop = ({ articles = [], onComplete, requiredReadingTime = 10 }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(requiredReadingTime);
  const [responses, setResponses] = useState({ comprehensionCheck: '', affect: '', polarization: '' });
  const [logs, setLogs] = useState([]);
  
  const scrollRef = useRef(null);
  const entryTimeRef = useRef(new Date());

  // Check if the content is short enough that it doesn't need scrolling
  const checkWhetherScrollIsRequired = () => {
    if (!scrollRef.current) return;
    const { scrollHeight, clientHeight } = scrollRef.current;
    
    // If the scrollable area is equal to or smaller than the visible container height,
    // it means there is no scrollbar, so we automatically mark it as scrolled to bottom.
    if (scrollHeight <= clientHeight + 5) {
      setHasScrolledToBottom(true);
    }
  };

  useEffect(() => {
    setHasScrolledToBottom(false);
    setSecondsRemaining(requiredReadingTime);
    setResponses({ comprehensionCheck: '', affect: '', polarization: '' });
    entryTimeRef.current = new Date();
    
    // Run the scroll check after the DOM updates and text renders fully
    const timer = setTimeout(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = 0;
      }
      checkWhetherScrollIsRequired();
    }, 50);

    const countdown = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(countdown);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearTimeout(timer);
      clearInterval(countdown);
    };
  }, [currentIndex, requiredReadingTime]);

  // Handle window resizing to re-evaluate scroll parameters dynamically
  useEffect(() => {
    window.addEventListener('resize', checkWhetherScrollIsRequired);
    return () => window.removeEventListener('resize', checkWhetherScrollIsRequired);
  }, [currentIndex]);

  if (!articles || articles.length === 0) {
    return (
      <div className="text-center p-6 text-xs text-red-600 font-bold bg-red-50 rounded-xl border border-red-200 font-sans">
        ⚠️ Error: Assigned article repository context is missing or empty.
      </div>
    );
  }

  const handleScroll = () => {
    if (!scrollRef.current || hasScrolledToBottom) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    if (scrollTop === 0) return;

    if (Math.abs(scrollHeight - clientHeight - scrollTop) < 10) {
      setHasScrolledToBottom(true);
    }
  };

  const handleRadioChange = (qId, val) => {
    setResponses(prev => ({ ...prev, [qId]: val }));
  };

  const handleNext = () => {
    if (!responses.comprehensionCheck || !responses.affect || !responses.polarization) {
      alert("Please complete all sections of the assessment before moving forward.");
      return;
    }

    const targetQuestion = articles[currentIndex].comprehensionQuestion;
    const currentLog = {
      articleId: articles[currentIndex].id,
      title: articles[currentIndex].title,
      category: articles[currentIndex].category,
      type: articles[currentIndex].type,
      timeSpentSeconds: Math.round((new Date() - entryTimeRef.current) / 1000),
      responses: {
        comprehensionCheckSelected: responses.comprehensionCheck,
        comprehensionCheckIsCorrect: responses.comprehensionCheck === targetQuestion?.correctAnswer,
        affect: parseInt(responses.affect, 10),
        polarization: parseInt(responses.polarization, 10)
      },
      evaluatedAt: new Date().toISOString()
    };

    const updatedLogs = [...logs, currentLog];
    setLogs(updatedLogs);

    if (currentIndex < articles.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      onComplete(updatedLogs);
    }
  };

  const currentArticle = articles[currentIndex];
  const isUnlocked = hasScrolledToBottom && secondsRemaining === 0;

  return (
    <div className="w-full bg-[#fcfcf9] min-h-screen font-serif text-gray-900 antialiased shadow-inner border border-gray-200 rounded-xl overflow-hidden">
      
      {/* Premium Premium Media Platform Navigation Header */}
      <header className="bg-white border-b-2 border-gray-900 px-6 py-4 sticky top-0 z-50 shadow-sm font-sans">
        <div className="flex justify-between items-center max-w-7xl mx-auto border-b border-gray-200 pb-2">
          <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
            LIVE NEWS NETWORK • EDITION 2026
          </div>
          <div className="text-2xl font-black tracking-tighter text-gray-950 italic font-serif">
            THE CHRONICLE
          </div>
          <div className="text-[11px] font-semibold bg-gray-900 text-white px-2.5 py-1 rounded">
            Subscriber Only
          </div>
        </div>
        <div className="flex justify-between items-center max-w-7xl mx-auto pt-2 text-[11px] font-medium text-gray-600">
          <div>Analysis & Opinions</div>
          <div className="capitalize">{currentArticle.category} Focus</div>
        </div>
      </header>

      {/* Main Multi-Column Layout Grid */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 items-start">
        
        {/* Left Column: Primary Investigative Article Context Body */}
        <main className="lg:col-span-7 bg-white border border-gray-200 rounded-lg shadow-sm p-6 sm:p-8">
          <div 
            className="max-h-[750px] overflow-y-auto pr-4 space-y-6 scrollbar-thin" 
            ref={scrollRef} 
            onScroll={handleScroll}
          >
            {/* News Article Metadata & Typography Block */}
            <div className="space-y-4 border-b border-gray-100 pb-6">
              <div className="flex items-center space-x-2">
                <span className="text-xs font-sans font-medium text-gray-500">
                  {currentArticle.meta}
                </span>
              </div>
              
              <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-gray-950 font-serif leading-tight">
                {currentArticle.title}
              </h1>
              
              <p className="text-lg text-gray-600 leading-relaxed font-sans border-l-4 border-gray-300 pl-4 py-1 italic">
                {currentArticle.subtitle}
              </p>
            </div>
            
            {/* News Editorial Content Paragraph Body */}
            <article className="text-base sm:text-lg text-gray-900 leading-serif-relaxed space-y-5 whitespace-pre-wrap font-serif tracking-normal">
              {currentArticle.content}
            </article>
          </div>
        </main>

        {/* Right Column: Dynamic Survey Form Dashboard & Progress Panel */}
        <aside className="lg:col-span-5 space-y-6 font-sans lg:sticky lg:top-[110px]">
          
          {/* Active Session Progress Monitor Widget Panel */}
          <div className="bg-gray-950 text-white p-4 rounded-lg shadow-sm">
            <h4 className="text-[10px] font-extrabold uppercase tracking-widest text-gray-400 mb-2">
              SESSION PROGRESS MONITOR
            </h4>
            <div className="space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-300">Article Queue Location:</span>
                <span className="font-bold text-sm text-white">{currentIndex + 1} / {articles.length}</span>
              </div>
              <div className="w-full bg-gray-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-blue-500 h-1.5 transition-all duration-300" 
                  style={{ width: `${((currentIndex + 1) / articles.length) * 100}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Integrated Dynamic Assessment Survey Area Container */}
          <div className="relative bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden">
            
            {/* Gate Overlay Backdrop overlay when locked */}
            {!isUnlocked && (
              <div className="absolute inset-0 bg-gray-50/80 backdrop-blur-xs z-40 flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
                <div className="bg-amber-100 text-amber-900 w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold mb-4">
                  ⏳
                </div>
                <h5 className="text-sm font-bold text-gray-950 mb-2">Survey Screen Locked</h5>
                <p className="text-xs text-gray-600 max-w-xs leading-relaxed">
                  {!hasScrolledToBottom 
                    ? "Please read through the entire article by scrolling to the bottom of the left context page to activate survey." 
                    : "Please finish reviewing the content material thoroughly until the countdown timer expires to unlock options."
                  }
                </p>
                {hasScrolledToBottom && secondsRemaining > 0 && (
                  <div className="mt-4 bg-amber-600 text-white px-4 py-1.5 rounded-full text-xs font-extrabold tracking-wider animate-pulse">
                    {secondsRemaining}s remaining
                  </div>
                )}
              </div>
            )}

            {/* Verification & Scales Input Form Panel */}
            <div className={`p-5 space-y-6 transition-all duration-300 ${!isUnlocked ? 'pointer-events-none opacity-40 select-none' : 'opacity-100'}`}>
              
              {/* Reader Comprehension Audit Check Section */}
              {currentArticle.comprehensionQuestion && (
                <div className="border-b border-gray-100 pb-5">
                  <div className="text-xs font-bold text-gray-900 mb-2.5 flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-gray-800"></span>
                    <span>{currentArticle.comprehensionQuestion.text}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 gap-2">
                    {currentArticle.comprehensionQuestion.options?.map((option, idx) => (
                      <label key={idx} className="flex items-center space-x-3 p-3 bg-gray-50 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50/10 cursor-pointer transition-all">
                        <input 
                          type="radio" 
                          name={`comp-${currentArticle.id}`} 
                          value={option} 
                          checked={responses.comprehensionCheck === option} 
                          onChange={() => handleRadioChange('comprehensionCheck', option)}
                          className="w-4 h-4 text-blue-600 accent-blue-600 cursor-pointer" 
                          disabled={!isUnlocked}
                        />
                        <span className="text-xs font-medium text-gray-700 leading-tight">{option}</span>
                      </label>
                    ))}
                  </div>
                </div>
              )}

              {/* Reader Perception & Sentiment Evaluation Scale Metrics Loop */}
              {SCALE_QUESTIONS.map((q) => (
                <div key={q.id} className="border-b border-gray-100 pb-5 last:border-none last:pb-0">
                  <h4 className="text-xs font-bold text-gray-900 mb-2.5 flex items-center space-x-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-gray-800"></span>
                    <span>{q.label}</span>
                  </h4>
                  
                  <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                    <div className="grid grid-cols-7 gap-0.5 text-center">
                      {[1, 2, 3, 4, 5, 6, 7].map((num) => {
                        let subLabel = "";
                        if (num === 1) subLabel = q.left;
                        if (num === 4) subLabel = q.mid;
                        if (num === 7) subLabel = q.right;

                        return (
                          <div key={num} className="flex flex-col items-center justify-between min-h-[65px]">
                            <div className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter min-h-[20px] flex items-center justify-center px-0.5 leading-tight select-none">
                              {subLabel && <span className="text-gray-500 font-medium block scale-90">{subLabel}</span>}
                            </div>
                            
                            <div className="text-[11px] font-bold text-gray-700 my-0.5">{num}</div>
                            
                            <input 
                              type="radio" 
                              name={`assigned-${currentArticle.id}-${q.id}`} 
                              value={num}
                              checked={responses[q.id] === String(num)} 
                              onChange={() => handleRadioChange(q.id, String(num))}
                              className="w-3.5 h-3.5 text-blue-600 cursor-pointer accent-blue-600"
                              disabled={!isUnlocked}
                            />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              ))}

              {/* Standardized Submission Controller Routing Action Button */}
              <div className="pt-2">
                <button
                  onClick={handleNext}
                  disabled={!isUnlocked}
                  className="w-full py-3.5 bg-gray-950 hover:bg-gray-900 disabled:bg-gray-300 text-white font-bold text-xs uppercase tracking-widest rounded-lg transition-all shadow-md cursor-pointer text-center block border border-transparent"
                >
                  {currentIndex < articles.length - 1 ? "Submit Metrics & Next Article ➔" : "Complete Evaluation Protocol ➔"}
                </button>
              </div>

            </div>
          </div>

        </aside>

      </div>
    </div>
  );
};

export default AssignedReadingLoop;