// src/components/step3NewsFeed.jsx
import React, { useState, useRef, useEffect } from 'react';

const SCALE_QUESTIONS = [
  { id: "affect", label: "How did reading this news article make you feel emotionally?", left: "Very Negative", mid: "Neutral", right: "Very Positive" },
  { id: "polarization", label: "How polarizing do you perceive the content of this article to be?", left: "Not polarizing at all", mid: "Moderately polarizing", right: "Extremely polarizing" }
];

const NewsFeedContainer = ({ articles = [], onComplete, requiredReadingTime = 10 }) => {
  const [activeArticle, setActiveArticle] = useState(null);
  const [hasScrolledToBottom, setHasScrolledToBottom] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(requiredReadingTime); 
  const [responses, setResponses] = useState({ comprehensionCheck: '', affect: '', polarization: '' });
  const [clickLogs, setClickLogs] = useState([]);
  
  const activeLogRef = useRef(null); 
  const scrollRef = useRef(null);

  // Check if the modal content is short enough that it doesn't need scrolling
  const checkWhetherScrollIsRequired = () => {
    if (!scrollRef.current) return;
    const { scrollHeight, clientHeight } = scrollRef.current;
    if (scrollHeight <= clientHeight + 5) {
      setHasScrolledToBottom(true);
    }
  };

  useEffect(() => {
    if (!activeArticle) return;

    setHasScrolledToBottom(false);
    setSecondsRemaining(requiredReadingTime); 
    setResponses({ comprehensionCheck: '', affect: '', polarization: '' });
    activeLogRef.current = { openedAt: new Date().toISOString() };

    const timer = setTimeout(() => {
      if (scrollRef.current) {
        scrollRef.current.scrollTop = 0;
      }
      checkWhetherScrollIsRequired();
    }, 50);

    const countdown = setInterval(() => {
      setSecondsRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(countdown);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      clearTimeout(timer);
      clearInterval(countdown);
    };
  }, [activeArticle, requiredReadingTime]);

  useEffect(() => {
    if (activeArticle) {
      window.addEventListener('resize', checkWhetherScrollIsRequired);
    }
    return () => window.removeEventListener('resize', checkWhetherScrollIsRequired);
  }, [activeArticle]);

  const handleOpenArticle = (article) => {
    const alreadyRead = clickLogs.some(log => String(log.articleId) === String(article.id));
    if (alreadyRead) {
      alert("You have already evaluated this article context repository element.");
      return;
    }
    setActiveArticle(article);
  };

  const handleScroll = () => {
    if (!scrollRef.current || hasScrolledToBottom) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    if (scrollTop === 0) return;

    if (Math.abs(scrollHeight - clientHeight - scrollTop) < 10) {
      setHasScrolledToBottom(true);
    }
  };

  const handleRadioChange = (qId, val) => {
    setResponses(prev => ({ ...prev, [qId]: val }));
  };

  const handleCloseArticleWithData = () => {
    if (!responses.comprehensionCheck || !responses.affect || !responses.polarization) {
      alert("Please complete all sections of the assessment before moving forward.");
      return;
    }

    const currentLog = {
      articleId: activeArticle.id,
      title: activeArticle.title,
      category: activeArticle.category,
      type: activeArticle.type,
      timeSpentSeconds: Math.round((new Date() - new Date(activeLogRef.current.openedAt)) / 1000),
      responses: {
        comprehensionCheckSelected: responses.comprehensionCheck,
        comprehensionCheckIsCorrect: responses.comprehensionCheck === activeArticle.comprehensionQuestion?.correctAnswer,
        affect: parseInt(responses.affect, 10),
        polarization: parseInt(responses.polarization, 10)
      },
      openedAt: activeLogRef.current.openedAt,
      closedAt: new Date().toISOString()
    };

    const updatedLogs = [...clickLogs, currentLog];
    setClickLogs(updatedLogs);
    setActiveArticle(null);

    if (updatedLogs.length >= 3) {
      onComplete(updatedLogs);
    }
  };

  return (
    <div className="w-full bg-gray-50 min-h-screen font-sans antialiased text-gray-900 pb-12">
      
      {/* Top Banner Feed Tracker Status Header Container */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-30 shadow-xs">
        <div className="max-w-7xl mx-auto px-6 py-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div>
            <h1 className="text-lg font-black tracking-tight text-gray-900">Customized News Feed Protocol</h1>
            <p className="text-xs text-gray-500 font-medium">Please explicitly review and evaluate every operational node item listed below contextually.</p>
          </div>
          <div className="bg-gray-900 text-white px-4 py-2 rounded-lg flex items-center space-x-3 text-xs font-bold">
            <span className="text-gray-400">Feed Coverage Progress:</span>
            <span className="text-blue-400 text-sm">{clickLogs.length} / 3 Read</span>
          </div>
        </div>
      </div>

      {/* Main Dynamic News Stream Card Feed Node Loop (Restored to 4*3 Grid Matrix) */}
      <div className="max-w-7xl mx-auto px-6 pt-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {articles.map((article) => {
            const isRead = clickLogs.some(log => String(log.articleId) === String(article.id));
            
            return (
              <div 
                key={article.id}
                onClick={() => handleOpenArticle(article)}
                className={`bg-white border transition-all duration-200 rounded-xl p-5 shadow-xs flex flex-col justify-between relative overflow-hidden h-64 ${
                  isRead 
                    ? 'border-gray-200 opacity-55 cursor-not-allowed bg-gray-50/50 select-none' 
                    : 'border-gray-200 hover:border-gray-400 hover:shadow-md cursor-pointer'
                }`}
              >
                <div className="space-y-2.5 flex-1 min-h-0 overflow-hidden">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold uppercase tracking-widest px-2.5 py-1 bg-gray-100 text-gray-600 rounded-md truncate max-w-[70%]">
                      {article.category}
                    </span>
                    {isRead && (
                      <span className="text-[10px] font-bold text-green-700 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full flex items-center space-x-1 flex-shrink-0">
                        <span>✓</span> <span>Completed</span>
                      </span>
                    )}
                  </div>

                  <h2 className="text-base font-bold text-gray-950 tracking-tight leading-snug font-serif hover:text-blue-900 transition-colors line-clamp-3">
                    {article.title}
                  </h2>

                  <p className="text-xs text-gray-600 line-clamp-3 leading-relaxed">
                    {article.subtitle}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-gray-100 flex items-center justify-between text-[11px] font-medium text-gray-400 flex-shrink-0">
                  <span className="truncate max-w-[50%]">{article.meta}</span>
                  {!isRead && <span className="text-blue-600 font-semibold group-hover:underline flex-shrink-0">Open Article ➔</span>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Enhanced Multi-Column Fullscreen Modal Element (Styled exactly like step2NewsRead) */}
      {activeArticle && (
        <div className="fixed inset-0 z-50 bg-gray-900/60 backdrop-blur-xs flex items-center justify-center p-0 sm:p-4 animate-fadeIn">
          <div className="bg-[#fcfcf9] w-full max-w-7xl h-full sm:h-[90vh] sm:max-h-[850px] shadow-2xl sm:rounded-xl border border-gray-300 flex flex-col overflow-hidden animate-scaleUp">
            
            {/* Premium Media Platform Navigation Header (step2 Architecture) */}
            <header className="bg-white border-b-2 border-gray-900 px-6 py-4 sticky top-0 z-50 shadow-sm font-sans flex-shrink-0">
              <div className="flex justify-between items-center max-w-7xl mx-auto border-b border-gray-200 pb-2">
                <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">
                  LIVE NEWS NETWORK • EDITION 2026
                </div>
                <div className="text-2xl font-black tracking-tighter text-gray-950 italic font-serif">
                  THE CHRONICLE
                </div>
                {/* Modified the button to a clickable X to close the modal without submission */}
                <button 
                  onClick={() => setActiveArticle(null)}
                  className="text-xs font-black bg-gray-100 hover:bg-gray-200 text-gray-800 px-3 py-1 rounded transition-colors"
                >
                  ✕
                </button>
              </div>
              <div className="flex justify-between items-center max-w-7xl mx-auto pt-2 text-[11px] font-medium text-gray-600">
                <div>Analysis & Opinions</div>
                <div className="capitalize">{activeArticle.category} Focus</div>
              </div>
            </header>

            {/* Main Multi-Column Content Matrix Container */}
            <div className="flex-1 min-h-0 grid grid-cols-1 lg:grid-cols-12 gap-8 p-6 overflow-y-auto items-start">
              
              {/* Left Column: Primary Investigative Article Context Body */}
              <main className="lg:col-span-7 bg-white border border-gray-200 rounded-lg shadow-sm p-6 sm:p-8 h-full flex flex-col min-h-0">
                <div 
                  className="overflow-y-auto pr-4 space-y-6 scrollbar-thin flex-1 max-h-[600px]" 
                  ref={scrollRef} 
                  onScroll={handleScroll}
                >
                  {/* News Article Metadata & Typography Block */}
                  <div className="space-y-4 border-b border-gray-100 pb-6">
                    <div className="flex items-center space-x-2">
                      <span className="text-xs font-sans font-medium text-gray-500">
                        {activeArticle.meta}
                      </span>
                    </div>
                    
                    <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-gray-950 font-serif leading-tight">
                      {activeArticle.title}
                    </h1>
                    
                    <p className="text-lg text-gray-600 leading-relaxed font-sans border-l-4 border-gray-300 pl-4 py-1 italic">
                      {activeArticle.subtitle}
                    </p>
                  </div>
                  
                  {/* News Editorial Content Paragraph Body */}
                  <article className="text-base sm:text-lg text-gray-900 leading-serif-relaxed space-y-5 whitespace-pre-wrap font-serif tracking-normal">
                    {activeArticle.content}
                  </article>
                </div>
              </main>

              {/* Right Column: Dynamic Survey Form Dashboard & Progress Panel */}
              <aside className="lg:col-span-5 space-y-6 font-sans h-full overflow-y-auto">
                
                {/* Integrated Dynamic Assessment Survey Area Container */}
                <div className="relative bg-white border border-gray-200 rounded-lg shadow-sm overflow-hidden min-h-[300px]">
                  
                  {/* Gate Overlay Backdrop overlay when locked */}
                  {!hasScrolledToBottom || secondsRemaining > 0 ? (
                    <div className="absolute inset-0 bg-gray-50/80 backdrop-blur-xs z-40 flex flex-col items-center justify-center p-6 text-center animate-fadeIn">
                      <div className="bg-amber-100 text-amber-900 w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold mb-4">
                        ⏳
                      </div>
                      <h5 className="text-sm font-bold text-gray-950 mb-2">Survey Screen Locked</h5>
                      <p className="text-xs text-gray-600 max-w-xs leading-relaxed">
                        {!hasScrolledToBottom 
                          ? "Please read through the entire article by scrolling to the bottom of the left context page to activate evaluation metrics." 
                          : "Please finish reviewing the content material thoroughly until the countdown timer expires to unlock options."
                        }
                      </p>
                      {hasScrolledToBottom && secondsRemaining > 0 && (
                        <div className="mt-4 bg-amber-600 text-white px-4 py-1.5 rounded-full text-xs font-extrabold tracking-wider animate-pulse">
                          {secondsRemaining}s remaining
                        </div>
                      )}
                    </div>
                  ) : null}

                  {/* Verification & Scales Input Form Panel */}
                  <div className="p-5 space-y-6">
                    
                    {/* Reader Comprehension Audit Check Section */}
                    {activeArticle.comprehensionQuestion && (
                      <div className="border-b border-gray-100 pb-5">
                        <div className="text-xs font-bold text-gray-900 mb-2.5 flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-gray-800"></span>
                          <span>{activeArticle.comprehensionQuestion.text}</span>
                        </div>
                        
                        <div className="grid grid-cols-1 gap-2">
                          {activeArticle.comprehensionQuestion.options?.map((option, idx) => (
                            <label key={idx} className="flex items-center space-x-3 p-3 bg-gray-50 border border-gray-200 rounded-lg hover:border-blue-500 hover:bg-blue-50/10 cursor-pointer transition-all">
                              <input 
                                type="radio" 
                                name={`modal-comp-${activeArticle.id}`} 
                                value={option} 
                                checked={responses.comprehensionCheck === option} 
                                onChange={() => handleRadioChange('comprehensionCheck', option)}
                                className="w-4 h-4 text-blue-600 accent-blue-600 cursor-pointer" 
                              />
                              <span className="text-xs font-medium text-gray-700 leading-tight">{option}</span>
                            </label>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Reader Perception & Sentiment Evaluation Scale Metrics Loop */}
                    {SCALE_QUESTIONS.map((q) => (
                      <div key={q.id} className="border-b border-gray-100 pb-5 last:border-none last:pb-0">
                        <h4 className="text-xs font-bold text-gray-900 mb-2.5 flex items-center space-x-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-gray-800"></span>
                          <span>{q.label}</span>
                        </h4>
                        
                        <div className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                          <div className="grid grid-cols-7 gap-0.5 text-center">
                            {[1, 2, 3, 4, 5, 6, 7].map((num) => {
                              let subLabel = "";
                              if (num === 1) subLabel = q.left;
                              if (num === 4) subLabel = q.mid;
                              if (num === 7) subLabel = q.right;

                              return (
                                <div key={num} className="flex flex-col items-center justify-between min-h-[65px]">
                                  <div className="text-[8px] font-bold text-gray-400 uppercase tracking-tighter min-h-[20px] flex items-center justify-center px-0.5 leading-tight select-none">
                                    {subLabel && <span className="text-gray-500 font-medium block scale-90">{subLabel}</span>}
                                  </div>
                                  
                                  <div className="text-[11px] font-bold text-gray-700 my-0.5">{num}</div>
                                  
                                  <input 
                                    type="radio" 
                                    name={`modal-${activeArticle.id}-${q.id}`} 
                                    value={num}
                                    checked={responses[q.id] === String(num)} 
                                    onChange={() => handleRadioChange(q.id, String(num))}
                                    className="w-3.5 h-3.5 text-blue-600 cursor-pointer accent-blue-600"
                                  />
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Standardized Submission Controller Routing Action Button */}
                    <div className="pt-2">
                      <button
                        onClick={handleCloseArticleWithData}
                        className="w-full py-3.5 bg-gray-950 hover:bg-gray-900 disabled:bg-gray-300 text-white font-bold text-xs uppercase tracking-widest rounded-lg transition-all shadow-md cursor-pointer text-center block border border-transparent"
                      >
                        Save Response & Return to Feed ➔
                      </button>
                    </div>

                  </div>
                </div>

              </aside>

            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default NewsFeedContainer;