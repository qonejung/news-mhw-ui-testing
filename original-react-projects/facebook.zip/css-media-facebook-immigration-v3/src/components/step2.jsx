// src/components/step2.jsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import allArticles from '../data/step2Articles.json';
import { ARTICLE_CONTINUE_DELAY_SECONDS, TEST_DEFAULT_TOPIC, TEST_MODE } from '../config/experimentConfig';

const TOPIC_LABELS = {
  IMMIGRATION: 'Immigration policy',
  CLIMATE: 'Climate change action',
  GENDER_LGBTQ: 'Gender equality and LGBTQ+ rights',
};

// Keep these aligned with Step 1. The uploaded survey names the STAI-6 items
// but does not specify response labels, so these remain a development default.
const STAI_RESPONSE_LABELS = {
  1: 'Not at all',
  2: 'Somewhat',
  3: 'Moderately so',
  4: 'Very much so',
};

const STAI_ITEMS = [
  ['calm', 'I feel calm'],
  ['tense', 'I am tense'],
  ['upset', 'I feel upset'],
  ['relaxed', 'I am relaxed'],
  ['content', 'I feel content'],
  ['worried', 'I am worried'],
];

const PANAS_ITEMS = [
  ['upset', 'Upset'],
  ['hostile', 'Hostile'],
  ['alert', 'Alert'],
  ['ashamed', 'Ashamed'],
  ['inspired', 'Inspired'],
  ['nervous', 'Nervous'],
  ['determined', 'Determined'],
  ['attentive', 'Attentive'],
  ['afraid', 'Afraid'],
  ['active', 'Active'],
];

const emptyPostExposure = {
  sam: {
    valence: '',
    arousal: '',
    dominance: '',
  },
  stai: {
    calm: '',
    tense: '',
    upset: '',
    relaxed: '',
    content: '',
    worried: '',
  },
  stress: '',
  panas: {
    upset: '',
    hostile: '',
    alert: '',
    ashamed: '',
    inspired: '',
    nervous: '',
    determined: '',
    attentive: '',
    afraid: '',
    active: '',
  },
  perceivedPolarization: '',
};

const randomIndex = (length) => {
  if (length <= 1) return 0;

  if (typeof crypto !== 'undefined' && crypto.getRandomValues) {
    const randomRange = 0x100000000;
    const limit = randomRange - (randomRange % length);
    const buffer = new Uint32Array(1);

    do {
      crypto.getRandomValues(buffer);
    } while (buffer[0] >= limit);

    return buffer[0] % length;
  }

  return Math.floor(Math.random() * length);
};

const shuffleArray = (items) => {
  const copy = [...items];

  for (let index = copy.length - 1; index > 0; index -= 1) {
    const swapIndex = randomIndex(index + 1);
    [copy[index], copy[swapIndex]] = [copy[swapIndex], copy[index]];
  }

  return copy;
};

const SectionHeading = ({ children }) => (
  <h2 className="text-lg font-bold text-blue-800 border-b pb-2 border-gray-200 uppercase tracking-wide">
    {children}
  </h2>
);

const QuestionBox = ({ label, children, description }) => (
  <div className="space-y-3 text-left">
    <div>
      <label className="block text-base font-bold text-gray-900 leading-snug whitespace-pre-line">
        {label}
      </label>
      {description && (
        <p className="mt-1 text-sm leading-relaxed text-gray-500">{description}</p>
      )}
    </div>
    <div className="w-full">{children}</div>
  </div>
);

const RadioList = ({ name, value, options, onChange }) => (
  <div className="flex flex-col space-y-3 text-base">
    {options.map((option) => (
      <label key={option.value} className="flex items-start gap-3 cursor-pointer py-0.5">
        <input
          type="radio"
          name={name}
          value={option.value}
          checked={value === option.value}
          onChange={() => onChange(option.value)}
          className="w-5 h-5 mt-0.5 text-blue-600 focus:ring-blue-500 flex-shrink-0"
        />
        <span className="text-gray-700 font-medium leading-tight">{option.label}</span>
      </label>
    ))}
  </div>
);

const LikertScale = ({ name, value, min = 1, max = 7, labels = {}, onChange }) => {
  const values = Array.from({ length: max - min + 1 }, (_, index) => min + index);
  const labelEntries = Object.entries(labels);
  const useAnchorLabels = labelEntries.length > 0 && labelEntries.length <= 3;
  const gridStyle = { gridTemplateColumns: `repeat(${values.length}, minmax(0, 1fr))` };

  return (
    <div className="bg-gray-50 p-3 sm:p-4 rounded-xl border border-gray-200 w-full">
      <div className="grid gap-0.5 sm:gap-2 text-center items-start px-2 sm:px-6" style={gridStyle}>
        {values.map((number) => (
          <label key={number} className="min-w-0 flex flex-col items-center gap-2 cursor-pointer">
            <span className="text-sm font-semibold text-gray-600">{number}</span>
            <input
              type="radio"
              name={name}
              value={number}
              checked={value === String(number)}
              onChange={() => onChange(String(number))}
              className="w-5 h-5 text-blue-600 cursor-pointer shrink-0"
              aria-label={`${name}: ${number}${labels[number] ? `, ${labels[number]}` : ''}`}
            />
            {!useAnchorLabels && labels[number] && (
              <span className="text-xs sm:text-sm text-gray-500 font-normal leading-snug break-words text-center">
                {labels[number]}
              </span>
            )}
          </label>
        ))}
      </div>

      {useAnchorLabels && (
        <div
          className="grid gap-0.5 sm:gap-2 mt-4 px-2 sm:px-6 text-xs sm:text-sm text-gray-600 leading-snug"
          style={gridStyle}
        >
          {values.map((number) => (
            <div key={`label-${number}`} className="min-w-0 flex justify-center text-center">
              {labels[number] ? (
                <span className="w-full max-w-[14rem] break-words">{labels[number]}</span>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const SAM_DETAILS = {
  Valence: {
    description: 'Your emotional feeling, from unhappy/unpleasant to happy/pleasant',
    imageSrc: '/images/sam_valence.png',
    imageAlt: 'SAM valence scale from unhappy or unpleasant to happy or pleasant',
  },
  Arousal: {
    description: 'Your level of activation, from calm/sleepy to excited/wide awake',
    imageSrc: '/images/sam_arousal.png',
    imageAlt: 'SAM arousal scale from calm or sleepy to excited or wide awake',
  },
  Dominance: {
    description: 'Your sense of control, from controlled/helpless to in control/powerful',
    imageSrc: '/images/sam_dominance.png',
    imageAlt: 'SAM dominance scale from controlled or helpless to in control or powerful',
  },
};

const SamScale = ({ dimension, value, onChange }) => {
  const details = SAM_DETAILS[dimension];

  return (
    <div className="rounded-xl border border-gray-200 bg-gray-50 p-4 sm:p-5 space-y-4">
      <p className="text-base sm:text-lg font-semibold text-gray-800 leading-relaxed">
        {dimension}: <span className="font-normal text-gray-600">{details.description}</span>
      </p>
      <div className="rounded-lg border border-gray-200 bg-white p-3 sm:p-4">
        <img
          src={details.imageSrc}
          alt={details.imageAlt}
          className="block w-full max-w-[668px] h-auto mx-auto"
        />
      </div>
      <LikertScale
        name={`post-sam-${dimension.toLowerCase()}`}
        value={value}
        min={1}
        max={9}
        onChange={onChange}
      />
    </div>
  );
};

const toNullableNumber = (value) => (value === '' || value === null || value === undefined ? null : Number(value));

const TrueFalseQuestion = ({ name, statement, value, onChange }) => (
  <div className="rounded-xl border border-gray-200 p-4 bg-gray-50 space-y-3">
    <p className="text-base font-medium text-gray-800 leading-relaxed">{statement}</p>
    <div className="flex flex-wrap gap-6 text-base">
      {[
        ['TRUE', 'True'],
        ['FALSE', 'False'],
      ].map(([optionValue, optionLabel]) => (
        <label key={optionValue} className="flex items-center gap-2 cursor-pointer">
          <input
            type="radio"
            name={name}
            value={optionValue}
            checked={value === optionValue}
            onChange={() => onChange(optionValue)}
            className="w-4 h-4 text-blue-600 focus:ring-blue-500"
          />
          <span className="font-medium text-gray-700">{optionLabel}</span>
        </label>
      ))}
    </div>
  </div>
);

const Step2 = ({ selectedTopic, assignedCondition, onTopicSelected, onComplete }) => {
  const [topicChoice, setTopicChoice] = useState(TEST_MODE ? TEST_DEFAULT_TOPIC : '');
  const articles = useMemo(() => {
    if (!selectedTopic || !assignedCondition) return [];

    const matched = allArticles.filter(
      (article) => article.topic === selectedTopic && article.condition === assignedCondition,
    );

    return shuffleArray(matched);
  }, [selectedTopic, assignedCondition]);

  const [phase, setPhase] = useState('intro');
  const [pendingStart, setPendingStart] = useState(false);
  const [articleIndex, setArticleIndex] = useState(0);
  const [articleLogs, setArticleLogs] = useState([]);
  const [articleStartedAt, setArticleStartedAt] = useState(null);
  const [reachedArticleEnd, setReachedArticleEnd] = useState(false);
  const [secondsRemaining, setSecondsRemaining] = useState(ARTICLE_CONTINUE_DELAY_SECONDS);
  const [postExposure, setPostExposure] = useState(emptyPostExposure);
  const [attentionResponses, setAttentionResponses] = useState({});
  const [validationMessage, setValidationMessage] = useState('');
  const endSentinelRef = useRef(null);

  const currentArticle = articles[articleIndex];
  const topicLabel = TOPIC_LABELS[selectedTopic] || selectedTopic;

  useEffect(() => {
    if (pendingStart && selectedTopic && assignedCondition && articles.length === 3) {
      setPendingStart(false);
      startReading();
    }
  }, [pendingStart, selectedTopic, assignedCondition, articles.length]);

  useEffect(() => {
    if (phase !== 'reading' || !endSentinelRef.current) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          setReachedArticleEnd(true);
        }
      },
      { threshold: 0.5 },
    );

    observer.observe(endSentinelRef.current);
    return () => observer.disconnect();
  }, [phase, articleIndex]);

  useEffect(() => {
    if (phase !== 'reading' || secondsRemaining <= 0) return undefined;

    const timer = window.setTimeout(() => {
      setSecondsRemaining((previous) => Math.max(0, previous - 1));
    }, 1000);

    return () => window.clearTimeout(timer);
  }, [phase, articleIndex, secondsRemaining]);

  const startReading = () => {
    setPhase('reading');
    setArticleIndex(0);
    setArticleStartedAt(Date.now());
    setReachedArticleEnd(false);
    setSecondsRemaining(ARTICLE_CONTINUE_DELAY_SECONDS);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const continueFromArticle = () => {
    if (!currentArticle || !reachedArticleEnd || secondsRemaining > 0) return;

    const responseValue = attentionResponses[currentArticle.id] || '';

    if (!TEST_MODE && responseValue === '') {
      setValidationMessage('Please answer the question about the article before continuing.');
      return;
    }

    const endedAt = Date.now();
    const startedAt = articleStartedAt || endedAt;
    const timeSpentSeconds = Math.max(0, Math.round((endedAt - startedAt) / 1000));

    const log = {
      articleId: currentArticle.id,
      coreId: currentArticle.coreId,
      title: currentArticle.title,
      presentationPosition: articleIndex + 1,
      startedAt: new Date(startedAt).toISOString(),
      completedAt: new Date(endedAt).toISOString(),
      timeSpentSeconds,
    };

    setArticleLogs((previous) => [...previous, log]);
    setValidationMessage('');

    if (articleIndex < articles.length - 1) {
      setArticleIndex((previous) => previous + 1);
      setArticleStartedAt(Date.now());
      setReachedArticleEnd(false);
      setSecondsRemaining(ARTICLE_CONTINUE_DELAY_SECONDS);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setPhase('survey');
    setArticleStartedAt(null);
    setReachedArticleEnd(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const updatePostNested = (group, key, value) => {
    setPostExposure((previous) => ({
      ...previous,
      [group]: {
        ...previous[group],
        [key]: value,
      },
    }));
    setValidationMessage('');
  };

  const updatePostField = (key, value) => {
    setPostExposure((previous) => ({ ...previous, [key]: value }));
    setValidationMessage('');
  };

  const updateAttention = (articleId, value) => {
    setAttentionResponses((previous) => ({ ...previous, [articleId]: value }));
    setValidationMessage('');
  };

  const validateSurvey = () => {
    if (TEST_MODE) return '';

    if (Object.values(postExposure.sam).some((value) => value === '')) {
      return 'Please complete all three SAM ratings.';
    }

    if (Object.values(postExposure.stai).some((value) => value === '')) {
      return 'Please complete all six state-anxiety items.';
    }

    if (postExposure.stress === '') {
      return 'Please complete the stress rating.';
    }

    if (Object.values(postExposure.panas).some((value) => value === '')) {
      return 'Please complete all ten affect ratings.';
    }

    if (postExposure.perceivedPolarization === '') {
      return 'Please answer the perceived-polarization question.';
    }

    return '';
  };

  const submitStep2 = (event) => {
    event.preventDefault();
    const message = validateSurvey();

    if (message) {
      setValidationMessage(message);
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    const attentionChecks = articles.map((article, index) => {
      const responseValue = attentionResponses[article.id] || '';
      const response = responseValue === '' ? null : responseValue === 'TRUE';
      const correctAnswer = Boolean(article.attentionCheck.correctAnswer);

      return {
        articleId: article.id,
        coreId: article.coreId,
        presentationPosition: index + 1,
        statement: article.attentionCheck.statement,
        response,
        correctAnswer,
        isCorrect: response === null ? null : response === correctAnswer,
      };
    });

    onComplete({
      topic: selectedTopic,
      assignedCondition,
      articleOrder: articles.map((article) => article.id),
      articles: articleLogs,
      postExposure: {
        sam: Object.fromEntries(
          Object.entries(postExposure.sam).map(([key, value]) => [key, toNullableNumber(value)]),
        ),
        stai: Object.fromEntries(
          Object.entries(postExposure.stai).map(([key, value]) => [key, toNullableNumber(value)]),
        ),
        stress: toNullableNumber(postExposure.stress),
        panas: Object.fromEntries(
          Object.entries(postExposure.panas).map(([key, value]) => [key, toNullableNumber(value)]),
        ),
      },
      perceivedPolarization: toNullableNumber(postExposure.perceivedPolarization),
      attentionChecks,
      attentionScore: attentionChecks.filter((check) => check.isCorrect === true).length,
      completedAt: new Date().toISOString(),
    });
  };

  if (selectedTopic && assignedCondition && articles.length !== 3) {
    return (
      <div className="bg-white rounded-xl shadow-md border border-red-200 p-8 md:p-10 text-left w-full mx-auto my-6">
        <h1 className="text-2xl font-bold text-red-800 mb-3">Step 2 configuration error</h1>
        <p className="text-base text-red-700 leading-relaxed">
          Expected exactly three articles for this topic and condition, but found {articles.length}.
        </p>
      </div>
    );
  }

  if (phase === 'intro') {
    const handleStart = () => {
      const topicToSubmit = selectedTopic || topicChoice || (TEST_MODE ? TEST_DEFAULT_TOPIC : '');

      if (!topicToSubmit) {
        setValidationMessage('Please select the issue you personally consider most important.');
        return;
      }

      setValidationMessage('');

      if (!selectedTopic || !assignedCondition) {
        setPendingStart(true);
        onTopicSelected(topicToSubmit);
        return;
      }

      startReading();
    };

    return (
      <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 2</p>
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Reading and Responding to News Articles</h1>
        <p className="text-base text-gray-600 leading-relaxed mb-5">
          You will read three short news articles about the issue you select below. Please read each article carefully and in full. At the end of each article, you will answer one brief true-or-false question while the article remains on the same page. After all three articles, you will answer a short set of questions about how you feel and about the articles overall.
        </p>
        <div className="rounded-lg border border-gray-200 bg-gray-50 p-4 text-base text-gray-700 leading-relaxed mb-7">
          A brief true-or-false question will appear directly below each article, so you can answer it while the article is still visible.
        </div>

        {validationMessage && (
          <div
            role="alert"
            className="mb-7 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
          >
            {validationMessage}
          </div>
        )}

        <div className="space-y-7">
          <QuestionBox label="Of the following three political and social issues, which one do you personally consider the most important?">
            <RadioList
              name="selectedTopic"
              value={selectedTopic || topicChoice}
              onChange={(value) => {
                setTopicChoice(value);
                setValidationMessage('');
              }}
              options={Object.entries(TOPIC_LABELS).map(([value, label]) => ({ value, label }))}
            />
          </QuestionBox>

          <div className="pt-4 border-t border-gray-200 flex justify-end">
            <button
              type="button"
              onClick={handleStart}
              className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
            >
              Start Article 1
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (phase === 'reading') {
    return (
      <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
        <div className="mb-6 border-b border-gray-100 pb-5">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 mb-4">
            <p className="text-sm font-semibold uppercase tracking-wide text-blue-600">
              Step 2 · Article {articleIndex + 1} of {articles.length}
            </p>
            <p className="text-sm text-gray-500">{topicLabel}</p>
          </div>
          <div className="grid grid-cols-3 gap-2" aria-hidden="true">
            {articles.map((article, index) => (
              <div
                key={article.id}
                className={`h-1.5 rounded-full ${index <= articleIndex ? 'bg-blue-600' : 'bg-gray-200'}`}
              />
            ))}
          </div>
        </div>

        <article className="max-w-none">
          <h1 className="text-2xl md:text-3xl font-serif font-bold text-gray-950 leading-tight mb-6">
            {currentArticle.title}
          </h1>
          <div className="space-y-5 text-[18px] leading-8 text-gray-800 font-serif">
            {currentArticle.body.map((paragraph, index) => (
              <p key={`${currentArticle.id}-paragraph-${index}`}>{paragraph}</p>
            ))}
          </div>
        </article>

        <div ref={endSentinelRef} className="h-px" aria-hidden="true" />

        <div className="mt-8 pt-7 border-t border-gray-200 space-y-6">
          <div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">A Quick Question About the Article</h2>
            <p className="text-base text-gray-600 leading-relaxed">
              Please answer this brief question based on the article above. The article will remain visible while you answer.
            </p>
          </div>

          <TrueFalseQuestion
            name={`attention-${currentArticle.id}`}
            statement={currentArticle.attentionCheck.statement}
            value={attentionResponses[currentArticle.id] || ''}
            onChange={(value) => updateAttention(currentArticle.id, value)}
          />

          {validationMessage && (
            <div
              role="alert"
              className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
            >
              {validationMessage}
            </div>
          )}

          <div className="pt-2">
            <p className="text-sm text-gray-500 leading-relaxed mb-4">
              {secondsRemaining > 0
                ? `Continue will be available in ${secondsRemaining} second${secondsRemaining === 1 ? '' : 's'}.`
                : !reachedArticleEnd
                  ? 'Please read to the end of the article before continuing.'
                  : 'You can continue when ready.'}
            </p>
            <button
              type="button"
              onClick={continueFromArticle}
              disabled={!reachedArticleEnd || secondsRemaining > 0}
              className={`w-full sm:w-auto px-8 py-3.5 font-semibold rounded-lg shadow-sm transition duration-200 text-base tracking-wide ${
                reachedArticleEnd && secondsRemaining === 0
                  ? 'bg-blue-600 text-white hover:bg-blue-700 cursor-pointer'
                  : 'bg-gray-200 text-gray-500 cursor-not-allowed'
              }`}
            >
              {articleIndex < articles.length - 1
                ? `Continue to Article ${articleIndex + 2}`
                : 'Continue to Questions'}
            </button>
          </div>
        </div>
      </div>
    );
  }


  return (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
      <div className="mb-7 border-b pb-6 border-gray-100">
        <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 2</p>
        <h1 className="text-3xl font-bold text-gray-900 mb-3">Questions After Reading the Articles</h1>
        <p className="text-base text-gray-600 leading-relaxed">
          Please answer the following questions based on how you feel now.
        </p>
      </div>

      {validationMessage && (
        <div
          role="alert"
          className="mb-7 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-base font-medium text-red-800"
        >
          {validationMessage}
        </div>
      )}

      <form onSubmit={submitStep2} className="space-y-10">
        <section className="space-y-8">
          <SectionHeading>Affective &amp; Psychological State</SectionHeading>

          <QuestionBox label="1. Please rate valence, arousal, and dominance using the 9-point scales below.">
            <div className="space-y-4">
              <SamScale
                dimension="Valence"
                value={postExposure.sam.valence}
                onChange={(value) => updatePostNested('sam', 'valence', value)}
              />
              <SamScale
                dimension="Arousal"
                value={postExposure.sam.arousal}
                onChange={(value) => updatePostNested('sam', 'arousal', value)}
              />
              <SamScale
                dimension="Dominance"
                value={postExposure.sam.dominance}
                onChange={(value) => updatePostNested('sam', 'dominance', value)}
              />
            </div>
          </QuestionBox>

          <QuestionBox label="2. Please indicate how you feel right now for each item.">
            <div className="space-y-4">
              {STAI_ITEMS.map(([key, label]) => (
                <div key={key} className="rounded-lg border border-gray-200 p-4">
                  <p className="mb-3 text-base font-medium text-gray-800">{label}</p>
                  <LikertScale
                    name={`post-stai-${key}`}
                    value={postExposure.stai[key]}
                    min={1}
                    max={4}
                    labels={STAI_RESPONSE_LABELS}
                    onChange={(value) => updatePostNested('stai', key, value)}
                  />
                </div>
              ))}
            </div>
          </QuestionBox>

          <QuestionBox label="3. On a scale of 0 to 10, with 0 being no stress and 10 being extreme stress, what number best describes your level of stress right now?">
            <LikertScale
              name="post-stress"
              value={postExposure.stress}
              min={0}
              max={10}
              labels={{ 0: 'No stress', 10: 'Extreme stress' }}
              onChange={(value) => updatePostField('stress', value)}
            />
          </QuestionBox>

          <QuestionBox label="4. Thinking about yourself and how you feel now, to what extent do you feel the following?">
            <div className="space-y-3">
              {PANAS_ITEMS.map(([key, label]) => (
                <div
                  key={key}
                  className="grid grid-cols-1 md:grid-cols-[180px_1fr] gap-3 md:items-center rounded-lg border border-gray-200 p-4"
                >
                  <p className="text-base font-semibold text-gray-800">{label}</p>
                  <LikertScale
                    name={`post-panas-${key}`}
                    value={postExposure.panas[key]}
                    min={1}
                    max={5}
                    labels={{ 1: 'Never', 5: 'Always' }}
                    onChange={(value) => updatePostNested('panas', key, value)}
                  />
                </div>
              ))}
            </div>
          </QuestionBox>
        </section>

        <section className="space-y-8">
          <SectionHeading>Perceived Polarization</SectionHeading>
          <QuestionBox label="5. Considering the three articles you just read, how polarizing did you find the articles overall?">
            <LikertScale
              name="perceived-polarization"
              value={postExposure.perceivedPolarization}
              min={1}
              max={7}
              labels={{ 1: 'Not at all polarizing', 7: 'Extremely polarizing' }}
              onChange={(value) => updatePostField('perceivedPolarization', value)}
            />
          </QuestionBox>
        </section>

        <div className="pt-4 border-t border-gray-200 flex justify-end">
          <button
            type="submit"
            className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
          >
            Complete Step 2
          </button>
        </div>
      </form>
    </div>
  );
};

export default Step2;
