// src/components/step3Intro.jsx
import React from 'react';

const Step3Intro = ({ onStart }) => (
  <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6 md:p-10 text-left w-full mx-auto my-6 font-sans">
    <p className="text-sm font-semibold uppercase tracking-wide text-blue-600 mb-2">Step 3</p>
    <h1 className="text-3xl font-bold text-gray-900 mb-4">News Article Choice</h1>
    <div className="space-y-4 text-base text-gray-600 leading-relaxed">
      <p>
        In this section, you will make two article choices.
      </p>
      <p>
        Each time, you will see previews of three different articles about the same issue and choose the one you would most like to read.
      </p>
      <p>
        After each choice, you may briefly explain what influenced your decision.
      </p>
    </div>

    <div className="pt-6 mt-6 border-t border-gray-100">
      <button
        type="button"
        onClick={onStart}
        className="w-full sm:w-auto px-8 py-3.5 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 transition duration-200 cursor-pointer text-base tracking-wide"
      >
        Start Article Choices
      </button>
    </div>
  </div>
);

export default Step3Intro;
