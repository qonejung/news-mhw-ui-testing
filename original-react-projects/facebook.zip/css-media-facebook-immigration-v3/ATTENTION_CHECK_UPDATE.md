# Step 2 attention-check update

The Step 2 attention check is now shown directly underneath each article, on the same page.

Flow:

1. Read Article 1.
2. Reach the end of the article and answer the inline True/False question directly below it.
3. Continue to Article 2.
4. Repeat for Article 2 and Article 3.
5. Complete the final affective/psychological-state and overall perceived-polarization questions.

The article remains visible above the attention question, and no correctness feedback is shown to participants.

The existing article delay remains controlled by `ARTICLE_CONTINUE_DELAY_SECONDS` in `src/config/experimentConfig.js` (currently 3 seconds). In `TEST_MODE`, an attention response is not required to continue. When `TEST_MODE` is false, it is required.
