# CSS Media Facebook-inspired immigration news feed — v3

A **mobile-first web prototype** for reviewing Step 2 news exposure. Participants would access it through a website URL, **not a native mobile app**. Only the Immigration article set is included; choosing Neutral, POLAR_POS, or POLAR_NEG in the hamburger menu displays three articles from that condition. Conditions are not shown in the participant-facing feed.

## Try the standalone demo

Open `css-media-facebook-preview.html` directly in a desktop or mobile browser. The file includes all required CSS, React runtime, and Immigration article text; it does not need a development server. You can also host it as a static web file. For React development, use `npm install` and `npm run dev` in this directory; `npm run build` produces a deployable Vite site.

## Reading interactions

- Each article opens in a CSS Media in-app reader and returns to its original position in the Facebook-style news feed.
- The reader optionally asks participants to **highlight exactly two sentences they find important**. Tap any sentence to highlight it yellow; tap it again to remove the highlight. A third selection is blocked until one of the two is removed. The same behavior works with keyboard focus and Enter/Space.
- The original True/False attention check from the uploaded source is optionally shown at the end of each article; answer submission is required, but a correct response is **not** required.
- **Back to news feed** marks an article as complete and becomes enabled only when *all currently enabled* requirements are met. By default these are (1) two highlighted sentences, (2) a submitted quiz answer, and (3) at least **10 seconds of foreground/visible article time**. Use X to close before completion; this produces an incomplete visit record without marking the article as read.
- The menu (**☰ → Prototype settings**) has independent switches for highlighting, attention check, and minimum visible time, plus an editable minimum in seconds (`0–600`; default `10`). Changing settings resets reading progress, highlights, and quiz answers without clearing prior interaction logs. Changing experimental condition also resets those reading states.

## Session-level logs

Every time an article is exited, a separate `articleSessions` object is created with:

- `articleId`, `title`, `condition`, `startedAt`, `endedAt`, and `status` (`completed`/`closed_early`)
- `elapsedMs` (wall-clock time since opening) and `visibleMs` (time the page was in the foreground; **not proof of attention**)
- `maxScrollPercent`, `scrollEventCount`, `scrollSamples[]` containing relative time, scroll position, depth and direction (throttled), `paragraphFirstVisibleMs` and `visibilityTransitions`
- selected highlights (paragraph index, sentence index, key and full sentence text)
- quiz response and correctness where applicable, plus a snapshot of the three enabled requirements and minimum seconds

The event log includes interactions such as opening and returning from articles, highlighting/unhighlighting, quiz submission, configuration changes and local social reaction actions. All records are maintained locally in memory and, where browser security permits, `localStorage` under `css-media-facebook-v3-interaction-log`. **No network call or study server is involved.** Use **Prototype settings → Export article sessions + event log (JSON)** to download both per-visit records and the event stream. The menu can also clear the stored logs.

*Implementation notes:* 

- Browsers may restrict local storage for a standalone `file://` page. Exporting the current session log should still work; serving the file from an HTTPS host gives reliable storage behavior.
- Scroll positions and foreground time cannot establish whether the participant truly read or understood the article. Time is measured separately for each opening of an article and is not accumulated across visits.
- Text preview remains a temporary excerpt from the first paragraph. Placeholder post copy and gray image slots are intentionally unchanged. The source article text and attention checks are preserved.
- All social interactions are local prototype interactions, not real posts or social-network activity.
- This prototype covers **Step 2 only**, not Step 1 surveys, post-exposure measures, or Step 3 choice.
- Settings are **prototype-only**; they must be hidden for actual study participants.

## Relevant React files

- `src/prototype/FacebookPrototype.jsx`: feed, article reader, highlighting, quiz, timing, gating, events, and export
- `src/prototype/facebook-prototype.css`: mobile layout and highlighting/settings styles
- `src/prototype/immigrationArticles.json`: existing nine Immigration article variants
- `src/App.jsx`: mounts the prototype

The included standalone HTML is a built artifact. For deployment or future changes, prefer the React/Vite project and `npm run build`.
