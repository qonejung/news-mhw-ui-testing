# SAM and Step 3 intro update

- Step 1 main title changed from `Baseline Survey` to `Background Information`.
- Added SAM images for Valence, Arousal, and Dominance in both Step 1 and Step 2.
- Added short participant-facing descriptions beside each SAM dimension name.
- SAM image files are stored in `public/images/` and referenced as `/images/sam_valence.png`, `/images/sam_arousal.png`, and `/images/sam_dominance.png`.
- Restored a Step 3 landing page before the three article-choice tasks. The old `step3Intro.jsx` had remained in the project but was no longer connected after Step 3 was rewritten; it is now updated and used again.
