# Step 3 implementation

Step 3 uses the remaining factual cores 04-06 for the topic selected in Step 1.

For each of the three factual cores:
- one NEUTRAL preview
- one POLAR_POS preview
- one POLAR_NEG preview

The three preview positions are randomized independently for each choice set. The order of factual cores 04-06 is also randomized once when Step 3 begins. Randomization is held stable for the lifetime of the mounted Step 3 component.

Each card shows the original article title and the first 70 words of the body by default. Change `STEP3_PREVIEW_WORD_LIMIT` in `src/config/experimentConfig.js` to adjust this.

The participant selects one card and may optionally explain the reason. In `TEST_MODE`, the choice can be skipped for development navigation; when `TEST_MODE` is false, one article must be selected before continuing.

Stored data include:
- topic
- Step 2 assigned condition
- randomized factual-core order
- randomized display order in each choice set
- selected article ID and condition
- optional free-text reason
- decision timing
