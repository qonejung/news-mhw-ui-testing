# UI update 2

Changes in this build:

- Step 1 header now follows the same hierarchy as Step 2: small blue `STEP 1`, large `Baseline Survey`, then instruction text.
- Step 2 participant-facing title changed from `News Article Exposure` to `Reading and Responding to News Articles`.
- Test mode is enabled. Survey validation is bypassed so pages can be advanced without completing every response.
- In test mode, Immigration is preselected only to keep Q10 branching and Step 2 article filtering functional when the tester skips all responses.
- Step 2 article Continue buttons require both reaching the end of the article and waiting for the configured delay. The current delay is 3 seconds.
- Test/final behavior and article delay are centralized in `src/config/experimentConfig.js`.
- Step 2 post-reading screen now uses `STEP 2` and `Questions After Reading the Articles`.
- `Post-Exposure Affective & Psychological State` changed to `Affective & Psychological State`.
- Development-only SAM image messages were removed. Images can be added later without changing the response data structure.
- Likert anchor labels now use the same column grid as the numbers and radio buttons, so endpoints and midpoint labels align vertically without changing spacing between response points.
- Stress endpoints changed to `No stress` and `Extreme stress`.
- Unanswered numeric test-mode responses are saved as `null` instead of being converted to zero.
- Unanswered True/False attention checks are saved as `null` and are not accidentally scored as false.

## Switching to final response validation

Open `src/config/experimentConfig.js` and change:

```js
export const TEST_MODE = true;
```

to:

```js
export const TEST_MODE = false;
```

## Changing article wait time

In the same file, change:

```js
export const ARTICLE_CONTINUE_DELAY_SECONDS = 3;
```

to the desired number of seconds.
